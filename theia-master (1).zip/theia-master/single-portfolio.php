<?php
/**
 * The template for displaying all single portfolios
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package THEIA
 */

get_header();
?>
    <div id="primary" class="u-content-background">
        <main id="main" class="u-content-top-spacing u-content-bottom-spacing">
            <div class="u-container-sides-spacing">
                <div class="o-wrapper u-container-width">
                    <div class="o-layout__single-portfolio">
                        <?php
                        while (have_posts()) :
                            the_post();

                            get_template_part('template-parts/content', 'single-portfolio');

                            if (comments_open() || get_comments_number()) :
                                comments_template();
                            endif;

                        endwhile;
                        ?>

                        <footer class="c-page__footer u-content-top-spacing">
                            <?php if (theia_option('active_related_posts')) { ?>

                                        <?php theia_related_portfolio_items() ?>

                            <?php } ?>

                        </footer>
                    </div>
                </div>
            </div>
        </main>
    </div>

<?php
get_footer();
