<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package THEIA
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="profile" href="http://gmpg.org/xfn/11">
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<div class="c-loader">
<div class="u-container-width">
    <?php
     $site_title = get_bloginfo('name');
     $site_title_arr = str_split(strtoupper($site_title));

     foreach($site_title_arr as $char){
         if($char === ' '){
             echo '<span>&nbsp;</span>';
         }
         echo '<span>'.$char.'</span>';
     }
     ?>
</div>
</div>
<?php

$header_classes = '';
    $header_classes .= theia_option('header_position', 'sticky') == 'sticky' ? 'c-header--sticky' : 'c-header--static';
    ?>

<header id="masthead" class="c-header <?php echo $header_classes; ?>">
    <div class="u-container-sides-spacing">
        <div class="o-wrapper u-container-width">
            <div class="c-navbar">
                <div class="c-navbar__zone c-navbar__zone--left">
                    <div class="site-branding">
                        <?php
                        the_custom_logo();
                        ?>

                         <h1 class="c-branding__title site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
                        <?php
                        $theia_description = get_bloginfo( 'description', 'display' );
                        if ( $theia_description || is_customize_preview() ) :
                            ?>
                            <p class="c-branding__description site-description"><?php echo $theia_description; /* WPCS: xss ok. */ ?></p>
                        <?php endif; ?>
                    </div><!-- .site-branding -->
                </div>
                <div class="c-navbar__zone c-navbar__zone--right">
                <?php if (class_exists('Woocommerce')) { ?>
                        <div class="c-navbar__cart-icon">
                            <a href="<?php echo wc_get_cart_url(); ?>"
                               class="side-cart__icon">
                                <span class="side-cart__number js-side-cart-number"><?php echo WC()->cart->cart_contents_count; ?></span>
                                <i class="fas fa-shopping-bag"></i>
                            </a>
                        </div>
                    <?php } ?>
                    <div class="c-navbar__search-icon"><span class="search-toggle"><i class="search-icon"></i></span>
                    </div>
                    <div class="c-navbar__search">
                        <div class="c-navbar__search-holder">
                            <div class="u-container-sides-spacing">
                                <div class="o-wrapper u-container-width">
                                    <form role="search" method="get" action="<?php echo esc_url(home_url('/')); ?>">
                                        <input type="search" autofocus class="search-field"
                                               placeholder="<?php echo esc_attr_x('Start Typing Here&hellip;', 'placeholder', 'theia'); ?>"
                                               value="<?php echo get_search_query(); ?>" name="s"
                                               title="<?php echo esc_attr_x('Search for:', 'label', 'theia'); ?>"/>
                                        <p><?php echo esc_html__('Press Enter/Return to start Search', 'theia'); ?></p>
                                        <input type="hidden" name="post_type" value="Search"/>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="c-navbar__hamburger--button" id="toggle-hamburger"><span class="top"></span><span
                                class="middle"></span><span class="bottom"></span></div>
                    <div class="c-navbar__hamburger" id="hamburger">
                        <nav class="c-navbar__hamburger--overlay">
                            <?php
                            wp_nav_menu(array(
                                'theme_location' => 'primary',
                                'menu_id' => 'primary-menu',
                                'container' => '',
                                'fallback_cb' => 'theia_primary_menu_fallback'

                            ));
                            ?>
                        </nav>
                        <div class="c-navbar__overlay--widget overlay-widget">
                            <?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('bottom-area')) :
                            endif; ?>
                        </div>

                    </div>
                </div>
            </div>
        </div>
</header>
<div id="page" class="site">

    <div id="content" class="site-content" >
        <?php if (!is_front_page() && !is_home()) { ?>
            <div class="c-navbar__zone c-navbar__extended u-content-width">
                <?php theia_breadcrumbs() ?>
            </div>
            <?php
        }
        ?>