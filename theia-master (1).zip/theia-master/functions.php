<?php
/**
 * THEIA functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package THEIA
 */

if (!function_exists('theia_setup')) {
    /**
     * Sets up theme defaults and registers support for various WordPress features.
     *
     * Note that this function is hooked into the after_setup_theme hook, which
     * runs before the init hook. The init hook is too late for some features, such
     * as indicating support for post thumbnails.
     */
    function theia_setup()
    {
        /*
         * Make theme available for translation.
         * Translations can be filed in the /languages/ directory.
         * If you're building a theme based on THEIA, use a find and replace
         * to change 'theia' to the name of your theme in all the template files.
         */
        load_theme_textdomain('theia', get_template_directory() . '/languages');

        // Add default posts and comments RSS feed links to head.
        add_theme_support('automatic-feed-links');

        /*
         * Let WordPress manage the document title.
         * By adding theme support, we declare that this theme does not use a
         * hard-coded <title> tag in the document head, and expect WordPress to
         * provide it for us.
         */
        add_theme_support('title-tag');

        /*
         * Enable support for Post Thumbnails on posts and pages.
         *
         * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
         */
        add_theme_support('post-thumbnails');

        // This theme uses wp_nav_menu() in one location.
        register_nav_menus(array(
            'primary' => esc_html__('Primary', 'theia')
        ));

        /*
         * Switch default core markup for search form, comment form, and comments
         * to output valid HTML5.
         */
        add_theme_support('html5', array(
            'search-form',
            'comment-form',
            'comment-list',
            'gallery',
            'caption',
        ));

        // Set up the WordPress core custom background feature.
        add_theme_support('custom-background', apply_filters('theia_custom_background_args', array(
            'default-color' => 'ffffff',
            'default-image' => '',
        )));

        // Add theme support for selective refresh for widgets.
        add_theme_support('customize-selective-refresh-widgets');

        /**
         * Add support for core custom logo.
         *
         * @link https://codex.wordpress.org/Theme_Logo
         */
        add_theme_support('custom-logo', array(
            'height' => 250,
            'width' => 250,
            'flex-width' => true,
            'flex-height' => true,
        ));
        add_editor_style( 'editor-style.css' );
    }
}
add_action('after_setup_theme', 'theia_setup');

/**
 * Enqueue scripts and styles.
 */

function load_theia_styles()
{
    wp_enqueue_style('theia-style', get_template_directory_uri() . '/style.css');
    wp_enqueue_style('fontawesome-css', get_template_directory_uri() . '/assets/css/font-awesome/fontawesome-all.min.css', array(), '5.0.9');
    wp_enqueue_style('chocolat-css', get_template_directory_uri() . '/assets/css/chocolat/chocolat.css', array(), '0.4.1.9');
}

add_action('wp_enqueue_scripts', 'load_theia_styles', 11);



function load_hero_area_scripts()
{
    if (is_front_page()) {
        wp_enqueue_script('pixi', get_theme_file_uri('/assets/js/vendor/pixi/pixi.min.js'), array(), '4.7.0', true);
        wp_enqueue_script('timelinelite', get_theme_file_uri('/assets/js/vendor/timelinelite/timelinelite.min.js'), array('jquery'), '1.20.4', true);
        wp_enqueue_script('tweenlite', get_theme_file_uri('/assets/js/vendor/tweenlite/tweenlite.min.js'), array('jquery'), '1.20.4', true);
    }
}

add_action('wp_enqueue_scripts', 'load_hero_area_scripts', 12);

function dequeue_woocommerce_scripts()
{
    if (function_exists('is_woocommerce')) {
        if (!is_woocommerce() && !is_shop() && !is_product_category() && !is_product() && !is_cart() && !is_checkout()) {
            wp_dequeue_style('theia-woocommerce-style');
            wp_dequeue_style('woocommerce_frontend_styles');
            wp_dequeue_style('woocommerce_fancybox_styles');
            wp_dequeue_style('woocommerce_chosen_styles');
            wp_dequeue_style('woocommerce_prettyPhoto_css');
            wp_dequeue_script('wc_price_slider');
            wp_dequeue_script('wc-single-product');
            wp_dequeue_script('wc-add-to-cart');
            wp_dequeue_script('wc-cart-fragments');
            wp_dequeue_script('wc-checkout');
            wp_dequeue_script('wc-add-to-cart-variation');
            wp_dequeue_script('wc-single-product');
            wp_dequeue_script('wc-cart');
            wp_dequeue_script('wc-chosen');
            wp_dequeue_script('woocommerce');
            wp_dequeue_script('prettyPhoto');
            wp_dequeue_script('prettyPhoto-init');
            wp_dequeue_script('jquery-blockui');
            wp_dequeue_script('jquery-placeholder');
            wp_dequeue_script('fancybox');
            wp_dequeue_script('jqueryui');
        }
    }
}

add_action('wp_enqueue_scripts', 'dequeue_woocommerce_scripts', 13);

function load_theia_global_scripts()
{
    wp_enqueue_script('theia-navigation', get_template_directory_uri() . '/assets/js/navigation.js', array(), '20151215', true);
    wp_enqueue_script('theia-skip-link-focus-fix', get_template_directory_uri() . '/assets/js/skip-link-focus-fix.js', array(), '20151215', true);
    wp_enqueue_script('chocolat', get_theme_file_uri('/assets/js/vendor/chocolat/jquery.chocolat.js'), array('jquery'), '0.4.1.9', true);
    wp_enqueue_script('imagesloaded', get_theme_file_uri('/assets/js/vendor/imagesloaded/imagesloaded.pkgd.min.js'), array('jquery'), '4.1.4', true);

    wp_enqueue_script('main', get_theme_file_uri('/assets/js/main.js'), array('jquery'), '1.0.0', true);

    if (is_singular() && comments_open() && get_option('thread_comments')) {
        wp_enqueue_script('comment-reply');
    }
}

add_action('wp_enqueue_scripts', 'load_theia_global_scripts', 14);

/**
 * Image sizes
 */
add_image_size('theia-single-featured-image', 1920, 9999, false);
add_image_size('theia-portfolio-grid-card', 500, 9999, false);
add_image_size('theia-blog-grid-card-landscape', 500, 250, false);
add_image_size('theia-related', 400, 275, true);
add_image_size('theia-related-porto', 700, 700, true);

add_image_size('theia-shop-grid-card', 330, 9999, false);
add_image_size('theia-shop-single-card', 640, 9999, false);
add_image_size('theia-shop-single-sidebar-card', 200, 9999, false);

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function theia_widgets_init()
{
    register_sidebar(array(
        'name' => esc_html__('Sidebar', 'theia'),
        'id' => 'sidebar-1',
        'description' => esc_html__('Add widgets here.', 'theia'),
        'before_widget' => '<section id="%1$s" class="c-sidebar__widget widget %2$s">',
        'after_widget' => '</section>',
        'before_title' => '<h2 class="c-sidebar__widget-title widget-title">',
        'after_title' => '</h2>',
    ));
    register_sidebar(array(
        'name' => esc_html__('Overlay Menu Widget Area', 'theia'),
        'id' => 'bottom-area',
        'description' => esc_html__('Add widgets here.', 'theia'),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget' => '</section>',
        'before_title' => '<h2 class="widget-title">',
        'after_title' => '</h2>',
    ));
    register_sidebar(array(
        'name' => esc_html__('Footer 1', 'theia'),
        'id' => 'footer-one',
        'description' => esc_html__('Add widgets here.', 'theia'),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget' => '</section>',
        'before_title' => '<h2 class="widget-title">',
        'after_title' => '</h2>',
    ));
    register_sidebar(array(
        'name' => esc_html__('Footer 2', 'theia'),
        'id' => 'footer-two',
        'description' => esc_html__('Add widgets here.', 'theia'),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget' => '</section>',
        'before_title' => '<h2 class="widget-title">',
        'after_title' => '</h2>',
    ));
    register_sidebar(array(
        'name' => esc_html__('Footer 3', 'theia'),
        'id' => 'footer-three',
        'description' => esc_html__('Add widgets here.', 'theia'),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget' => '</section>',
        'before_title' => '<h2 class="widget-title">',
        'after_title' => '</h2>',
    ));
}

add_action('widgets_init', 'theia_widgets_init');

/* Fallback function for menu */
function theia_primary_menu_fallback()
{
    ?>
    <ul id="menu" class="menu">
        <li><a href="/"><?php _e('Home', 'theia') ?></a></li>
        <li>
            <a href="<?php echo get_dashboard_url() ?>nav-menus.php"><?php _e('Menu is missing. Create and set primary menu.', 'theia') ?></a>
        </li>
    </ul>
    <?php
}

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function theia_content_width()
{
    // This variable is intended to be overruled from themes.
    // Open WPCS issue: {@link https://github.com/WordPress-Coding-Standards/WordPress-Coding-Standards/issues/1043}.
    // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
    $GLOBALS['content_width'] = apply_filters('theia_content_width', 640);
}

add_action('after_setup_theme', 'theia_content_width', 0);

/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
if (defined('JETPACK__VERSION')) {
    require get_template_directory() . '/inc/jetpack.php';
}

/**
 * Load WooCommerce compatibility file.
 */
if (class_exists('WooCommerce')) {
    require get_template_directory() . '/inc/woocommerce.php';
}

/**
 * THEIA INIT
 */

/* Load TGMPA */
require_once get_template_directory() . '/inc/required-plugins/required-plugins.php';

/* Load Merlin */
require_once get_template_directory() . '/inc/merlin/vendor/autoload.php';
require_once get_template_directory() . '/inc/merlin/class-merlin.php';
require_once get_template_directory() . '/inc/merlin-config.php';

//include customify config
require_once get_template_directory() . '/inc/integrations/customify.php';

// Include better comments file
require_once(get_template_directory() . '/inc/better-comments.php');

require_once get_template_directory() . '/inc/integrations/woocommerce-extras.php';
require_once get_template_directory() . '/inc/integrations/theia-extras.php';


// Blog navigation
function theia_numeric_posts_nav()
{

    if (is_singular())
        return;

    global $wp_query;

    /** Stop execution if there's only 1 page */
    if ($wp_query->max_num_pages <= 1)
        return;

    $paged = get_query_var('paged') ? absint(get_query_var('paged')) : 1;
    $max = intval($wp_query->max_num_pages);

    /** Add current page to the array */
    if ($paged >= 1)
        $links[] = $paged;

    /** Add the pages around the current page to the array */
    if ($paged >= 3) {
        $links[] = $paged - 1;
        $links[] = $paged - 2;
    }

    if (($paged + 2) <= $max) {
        $links[] = $paged + 2;
        $links[] = $paged + 1;
    }

    echo '<div class="c-navigation"><ul>' . "\n";

    /** Previous Post Link */
    if (get_previous_posts_link())
        printf('<li class="c-navigation__label">%s</li>' . "\n", get_previous_posts_link('prev'));

    /** Link to first page, plus ellipses if necessary */
    if (!in_array(1, $links)) {
        $class = 1 == $paged ? ' class="c-navigation__numbers c-navigation__numbers-active"' : '';

        printf('<li%s><a href="%s">%s</a></li>' . "\n", $class, esc_url(get_pagenum_link(1)), '1');

        if (!in_array(2, $links))
            echo '<li>...</li>';
    }

    /** Link to current page, plus 2 pages in either direction if necessary */
    sort($links);
    foreach ((array)$links as $link) {
        $class = $paged == $link ? ' class="c-navigation__numbers c-navigation__numbers-active"' : '';
        printf('<li %s><a href="%s">%s</a></li>' . "\n", $class, esc_url(get_pagenum_link($link)), $link);
    }

    /** Link to last page, plus ellipses if necessary */
    if (!in_array($max, $links)) {
        if (!in_array($max - 1, $links))
            echo '<li>...</li>' . "\n";

        $class = $paged == $max ? ' class="c-navigation__numbers-active"' : '';
        printf('<li%s><a href="%s">%s</a></li>' . "\n", $class, esc_url(get_pagenum_link($max)), $max);
    }

    /** Next Post Link */
    if (get_next_posts_link())
        printf('<li class="c-navigation__label">%s</li>' . "\n", get_next_posts_link('next'));

    echo '</ul></div>' . "\n";

}

// Related posts
function theia_related_posts()
{
    global $post;

    $current_post_type = get_post_type($post);

    // The query arguments
    $args = array(
        'posts_per_page' => 3,
        'order' => 'desc',
        'orderby' => 'rand',
        'post_type' => $current_post_type,
        'post__not_in' => array($post->ID)
    );

        $my_query = new wp_query($args);

        if ($my_query->have_posts()) {
            ?>
            <h3 class="c-related__title"><?php _e('Related posts', 'theia') ?></h3>
            <div class="c-related__gallery">
                <?php
                while ($my_query->have_posts()) {
                    $my_query->the_post();
                    ?>

                    <div class="c-related__thumb">
                        <a rel="external" class="c-related__thumb-link"
                           href="<?php the_permalink() ?>">
                            <?php if ( has_post_thumbnail() ) {
                                the_post_thumbnail('theia-related');
                            } else { ?>
                                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/placeholder.jpg" alt="<?php the_title(); ?>" />
                            <?php } ?>
                            <h5 class="c-related__thumb-title"><?php the_title(); ?></h5>
                            <div class="c-related__thumb-excerpt"><?php the_excerpt(); ?></div>
                        </a>
                    </div>

                    <?php
                }
                ?>
            </div>
            <?php
        }

    wp_reset_query();
}

// Related portfolio items
function theia_related_portfolio_items()
{

    // You might need to use wp_reset_query();
    // here if you have another query before this one

    global $post;

    $current_post_type = get_post_type($post);

    // The query arguments
    $args = array(
        'posts_per_page' => 3,
        'order' => 'desc',
        'orderby' => 'rand',
        'post_type' => $current_post_type,
        'post__not_in' => array($post->ID)
    );

    // Create the related query
    $rel_query = new WP_Query($args);

    // Check if there is any related posts
    if ($rel_query->have_posts()) :
        ?>
        <h3 class="c-related__title"><?php _e('Related projects', 'theia') ?></h3>
        <div class="c-related">
            <div class="c-related__gallery">
                <?php
                // The Loop
                while ($rel_query->have_posts()) :
                    $rel_query->the_post();
                    ?>

                    <div class="c-related__thumb c-related__thumb-portfolio">
                        <a rel="external" class="c-related__thumb--link" href="<?php the_permalink() ?>">
                            <div class="c-related__overlay"></div>
                            <div class="c-related__thumb--img">
                                <?php if ( has_post_thumbnail() ) {
                                    the_post_thumbnail('theia-related-porto');
                                } else { ?>
                                    <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/placeholder.jpg" alt="<?php the_title(); ?>" />
                                <?php } ?>
                            </div>
                            <div class="c-related__details">
                                <h5 class="c-related__details--title"><?php the_title(); ?></h5>
                            </div>
                        </a>
                    </div>
                <?php
                endwhile;
                ?>
            </div>
        </div>
    <?php
    endif;

    // Reset the query
    wp_reset_query();
}

// Author box
function theia_author_box()
{
    ?>
    <div class="c-author">
        <div class="c-author__avatar">
            <a href="<?php echo esc_url(get_author_posts_url(get_the_author_meta('ID'))); ?>"
               title="<?php the_author(); ?>"><?php echo get_avatar(get_the_author_meta('ID'), 100); ?>
            </a>
        </div>
        <div class="c-author__content">
            <h5 class="c-author__name"><?php esc_html(the_author()); ?></h5>
            <p class="c-author__description"><?php esc_html(the_author_meta('description')); ?></p>
            <a href="<?php echo get_author_posts_url(get_the_author_meta('ID'), get_the_author_meta('user_nicename')); ?>">
                <?php _e('All posts', 'theia'); ?>
            </a>
        </div>
    </div>
    <?php
}

// Social icons
function theia_social_icons()
{
    $post_link = get_the_permalink();
    $post_title = get_the_title();
    $social_string = theia_option('share_buttons_settings');

    if(empty($social_string)){
        return;
    }

    $socials_html = '';
    

    $socials = array(
        'facebook' => '<a target="_blank" rel="tooltip"
               data-original-title="' . esc_attr__("Share on Facebook", "theia") . '"
               href="https://www.facebook.com/sharer/sharer.php?u=' . esc_url($post_link) . '">
               <div class="c-social__btn"><i class="fab fa-facebook"></i></div></a>',
        'twitter' => '<a target="_blank" rel="tooltip"
               data-original-title="' . esc_attr__("Share on Twitter", "theia") . '"
               href="https://twitter.com/home?status=' . esc_url($post_link) . '">
               <div class="c-social__btn"><i class="fab fa-twitter"></i></div></a>',
        'google_plus' => '<a target="_blank" rel="tooltip"
               data-original-title="' . esc_attr__("Share on Google+", "theia") . '"
               href="https://plus.google.com/share?url=' . esc_url($post_link) . '"><div class="c-social__btn"><i class="fab fa-google"></i></div></a>',
        'pinterest' => '<a target="_blank" rel="tooltip"
               data-original-title="' . esc_attr__("Share on Pinterest", "theia") . '"
               href="https://pinterest.com/pin/create/bookmarklet/?url=' . esc_url($post_link) . '&description=' . esc_url($post_title) . '">
               <div class="c-social__btn"><i class="fab fa-pinterest"></i></div></a>',
        'linkedin' => '<a target="_blank" rel="tooltip"
               data-original-title="' . esc_attr__("Share on LinkedIn", "theia") . '"
               href="https://linkedin.com/shareArticle?url=' . esc_url($post_link) . '&title=' . esc_url($post_title) . '">
               <div class="c-social__btn"><i class="fab fa-linkedin"></i></div></a>',
        'tumblr' => '<a target="_blank" rel="tooltip"
               data-original-title="' . esc_attr__("Share on Tumblr", "theia") . '"
               href="https://tumblr.com/share/link?url=' . esc_url($post_link) . '&name=' . esc_url($post_title) . '">
               <div class="c-social__btn"><i class="fab fa-tumblr"></i></div></a>',
        'digg' => '<a target="_blank" rel="tooltip"
               data-original-title="' . esc_attr__("Share on Digg", "theia") . '"
               href="https://digg.com/submit?url=' . esc_url($post_link) . '&title=' . esc_url($post_title) . '">
               <div class="c-social__btn"><i class="fab fa-digg"></i></div></a>',
        'whatsapp' => '<a target="_blank" rel="tooltip"
               data-original-title="' . esc_attr__("Share on Whatsapp", "theia") . '"
               href="whatsapp://send?text=' . esc_url($post_link) . '">
               <div class="c-social__btn"><i class="fab fa-whatsapp"></i></div></a>',
        'email' => '<a rel="tooltip"
               data-original-title="' . esc_attr__("Share on email", "theia") . '"
               href="mailto:?body=' . esc_url($post_link) . '">
               <div class="c-social__btn"><i class="fas fa-envelope"></i></div></a>',

    );
    $social_trim = str_replace(' ', '', $social_string);
    $social_arr = explode(',', $social_trim);
    foreach ($social_arr as $social_item) {
        $socials_html .= $socials[$social_item];
    }
    ?>
    <div class="c-social">
        <div class="c-social__text"><i class="fas fa-share-alt"></i><span>Spread all over the world</span></div>
        <div class="c-social__blocks">

            <?php echo $socials_html; ?>

        </div>
    </div>
    <?php
}

// Stringify boolean
function theia_stringed_boolean($val)
{
    $res = $val === true ? 'true' : 'false';
    return $res;
}

function theia_add_class_to_images($class)
{
    $class .= ' chocolat-item';
    return $class;
}

add_filter('get_image_tag_class', 'theia_add_class_to_images');

function theia_portfolio_include_in_slider_checkbox($content, $post_id)
{
    if (get_post_type($post_id) != 'portfolio') {
        return $content;
    }

    $field_id = 'hero_area_featured';
    $field_value = esc_attr(get_post_meta($post_id, $field_id, true));
    $field_text = esc_html__('Include in Front Page Slider', 'theia');
    $field_state = checked($field_value, 1, false);

    $field_label = sprintf(
        '<div><b>Slider</b><hr/><label for="%1$s"><input type="checkbox" name="%1$s" id="%1$s" value="%2$s" %3$s> %4$s</label></div>',
        $field_id, $field_value, $field_state, $field_text
    );

    return $content .= $field_label;
}

function theia_portfolio_include_in_slider_save($post_ID, $post, $update)
{
    $field_id = 'hero_area_featured';
    $field_value = isset($_REQUEST[$field_id]) ? 1 : 0;

    update_post_meta($post_ID, $field_id, $field_value);

}

add_filter('admin_post_thumbnail_html', 'theia_portfolio_include_in_slider_checkbox', 10, 2);
add_action('save_post', 'theia_portfolio_include_in_slider_save', 10, 3);


//infinite scroll
function theia_blog_infinite_scroll_query()
{
    global $wp_query;
    $args = array(
        'url' => admin_url('admin-ajax.php'),
        'query' => $wp_query->query,
    );

    wp_localize_script('main', 'infiniteScrollObj', $args);

}

add_action('wp_enqueue_scripts', 'theia_blog_infinite_scroll_query', 15);

function theia_blog_infinite_scroll()
{
    $args = isset($_POST['query']) ? array_map('esc_attr', $_POST['query']) : array();
    $args['post_type'] = isset($args['post_type']) ? esc_attr($args['post_type']) : 'post';
    $args['paged'] = esc_attr($_POST['page']);
    $args['post_status'] = 'publish';
    ob_start();
    $loop = new WP_Query($args);
    if ($loop->have_posts()): while ($loop->have_posts()): $loop->the_post();
        get_template_part('template-parts/content', get_post_type());
    endwhile; endif;
    wp_reset_postdata();
    $data = ob_get_clean();
    wp_send_json_success($data);
    wp_die();
}

add_action('wp_ajax_theia_blog_infinite_scroll', 'theia_blog_infinite_scroll');
add_action('wp_ajax_nopriv_theia_blog_infinite_scroll', 'theia_blog_infinite_scroll');

function theia_blog_load_more_query()
{

    global $wp_query;
    $args = array(
        'url' => admin_url('admin-ajax.php'),
        'query' => $wp_query->query,
    );

    wp_localize_script('main', 'loadMoreObj', $args);

}

add_action('wp_enqueue_scripts', 'theia_blog_load_more_query', 16);

function theia_blog_load_more()
{
    $args = isset($_POST['query']) ? array_map('esc_attr', $_POST['query']) : array();
    $args['post_type'] = isset($args['post_type']) ? esc_attr($args['post_type']) : 'post';
    $args['paged'] = esc_attr($_POST['page']);
    $args['post_status'] = 'publish';
    ob_start();
    $loop = new WP_Query($args);
    if ($loop->have_posts()): while ($loop->have_posts()): $loop->the_post();
        get_template_part('template-parts/content', get_post_type());
    endwhile; endif;
    wp_reset_postdata();
    $data = ob_get_clean();
    wp_send_json_success($data);
    wp_die();
}

add_action('wp_ajax_theia_blog_load_more', 'theia_blog_load_more');
add_action('wp_ajax_nopriv_theia_blog_load_more', 'theia_blog_load_more');

// Breadcrumbs
function theia_breadcrumbs()
{

    // Settings
    $separator = '/';
    $breadcrums_id = 'breadcrumbs';
    $breadcrums_class = 'c-breadcrumb';
    $home_title = 'Homepage';

    // If you have any custom post types with custom taxonomies, put the taxonomy name below (e.g. product_cat)
    $custom_taxonomy = 'product_cat';

    // Get the query & post information
    global $post, $wp_query;

    // Do not display on the homepage
    if (!is_front_page()) {

        // Build the breadcrums
        echo '<ul id="' . $breadcrums_id . '" class="' . $breadcrums_class . '">';

        // Home page
        echo '<li class="c-breadcrumb__home"><a class="c-breadcrumb__link" href="' . get_home_url() . '" title="' . $home_title . '">' . $home_title . '</a></li>';
        echo '<li class="c-breadcrumb__separator c-breadcrumb__separator--home"> ' . $separator . ' </li>';

        if (is_archive() && !is_tax() && !is_category() && !is_tag()) {

            echo '<li class="c-breadcrumb__current c-breadcrumb__archive"><strong class="bread-current bread-archive">' . post_type_archive_title('', false) . '</strong></li>';

        } else if (is_archive() && is_tax() && !is_category() && !is_tag()) {

            // If post is a custom post type
            $post_type = get_post_type();

            // If it is a custom post type display name and link
            if ($post_type != 'post') {

                $post_type_object = get_post_type_object($post_type);
                $post_type_archive = get_post_type_archive_link($post_type);

                echo '<li class="c-breadcrumb__item-cat c-breadcrumb__type-' . $post_type . '"><a class="bread-cat bread-custom-post-type-' . $post_type . '" href="' . $post_type_archive . '" title="' . $post_type_object->labels->name . '">' . $post_type_object->labels->name . '</a></li>';
                echo '<li class="c-breadcrumb__separator"> ' . $separator . ' </li>';

            }

            $custom_tax_name = get_queried_object()->name;
            echo '<li class="c-breadcrumb__current c-breadcrumb__archive"><strong class="bread-current bread-archive">' . $custom_tax_name . '</strong></li>';

        } else if (is_single()) {

            // If post is a custom post type
            $post_type = get_post_type();

            // If it is a custom post type display name and link
            if ($post_type != 'post') {

                $post_type_object = get_post_type_object($post_type);
                $post_type_archive = get_post_type_archive_link($post_type);

                echo '<li class="c-breadcrumb__cat item-custom-post-type-' . $post_type . '"><a class="bread-cat bread-custom-post-type-' . $post_type . '" href="' . $post_type_archive . '" title="' . $post_type_object->labels->name . '">' . $post_type_object->labels->name . '</a></li>';
                echo '<li class="c-breadcrumb__separator"> ' . $separator . ' </li>';

            }

            // Get post category info
            $category = get_the_category();

            if (!empty($category)) {
                $arr = array_values($category);
                // Get last category post is in
                $last_category = end($arr);

                // Get parent any categories and create array
                $get_cat_parents = rtrim(get_category_parents($last_category->term_id, true, ','), ',');
                $cat_parents = explode(',', $get_cat_parents);

                // Loop through parent categories and store in variable $cat_display
                $cat_display = '';
                foreach ($cat_parents as $parents) {
                    $cat_display .= '<li class="c-breadcrumb__item-cat">' . $parents . '</li>';
                    $cat_display .= '<li class="c-breadcrumb__separator"> ' . $separator . ' </li>';
                }

            }

            // If it's a custom post type within a custom taxonomy
            $taxonomy_exists = taxonomy_exists($custom_taxonomy);
            if (empty($last_category) && !empty($custom_taxonomy) && $taxonomy_exists) {

                $taxonomy_terms = get_the_terms($post->ID, $custom_taxonomy);
                $cat_id = $taxonomy_terms[0]->term_id;
                $cat_nicename = $taxonomy_terms[0]->slug;
                $cat_link = get_term_link($taxonomy_terms[0]->term_id, $custom_taxonomy);
                $cat_name = $taxonomy_terms[0]->name;

            }

            // Check if the post is in a category
            if (!empty($last_category)) {
                echo $cat_display;
                echo '<li class="c-breadcrumb__current item-' . $post->ID . '"><strong class="bread-current bread-' . $post->ID . '" title="' . get_the_title() . '">' . get_the_title() . '</strong></li>';

                // Else if post is in a custom taxonomy
            } else if (!empty($cat_id)) {

                echo '<li class="c-breadcrumb__item-cat item-cat-' . $cat_id . ' item-cat-' . $cat_nicename . '"><a class="bread-cat bread-cat-' . $cat_id . ' bread-cat-' . $cat_nicename . '" href="' . $cat_link . '" title="' . $cat_name . '">' . $cat_name . '</a></li>';
                echo '<li class="c-breadcrumb__separator"> ' . $separator . ' </li>';
                echo '<li class="c-breadcrumb__current item-' . $post->ID . '"><strong class="bread-current bread-' . $post->ID . '" title="' . get_the_title() . '">' . get_the_title() . '</strong></li>';

            } else {

                echo '<li class="c-breadcrumb__current item-' . $post->ID . '"><strong class="bread-current bread-' . $post->ID . '" title="' . get_the_title() . '">' . get_the_title() . '</strong></li>';

            }

        } else if (is_category()) {

            // Category page
            echo '<li class="c-breadcrumb__current item-cat"><strong class="bread-current bread-cat">' . single_cat_title('', false) . '</strong></li>';

        } else if (is_page()) {

            // Standard page
            if ($post->post_parent) {

                // If child page, get parents
                $anc = get_post_ancestors($post->ID);

                // Get parents in the right order
                $anc = array_reverse($anc);

                // Parent page loop
                if (!isset($parents)) $parents = null;
                foreach ($anc as $ancestor) {
                    $parents .= '<li class="c-breadcrumb__parent item-parent-' . $ancestor . '"><a class="bread-parent bread-parent-' . $ancestor . '" href="' . get_permalink($ancestor) . '" title="' . get_the_title($ancestor) . '">' . get_the_title($ancestor) . '</a></li>';
                    $parents .= '<li class="c-breadcrumb__separator separator-' . $ancestor . '"> ' . $separator . ' </li>';
                }

                // Display parent pages
                echo $parents;

                // Current page
                echo '<li class="c-breadcrumb__current item-' . $post->ID . '"><strong title="' . get_the_title() . '"> ' . get_the_title() . '</strong></li>';

            } else {

                // Just display current page if not parents
                echo '<li class="c-breadcrumb__current item-' . $post->ID . '"><strong class="bread-current bread-' . $post->ID . '"> ' . get_the_title() . '</strong></li>';

            }

        } else if (is_tag()) {

            // Tag page

            // Get tag information
            $term_id = get_query_var('tag_id');
            $taxonomy = 'post_tag';
            $args = 'include=' . $term_id;
            $terms = get_terms($taxonomy, $args);
            $get_term_id = $terms[0]->term_id;
            $get_term_slug = $terms[0]->slug;
            $get_term_name = $terms[0]->name;

            // Display the tag name
            echo '<li class="c-breadcrumb__current item-tag-' . $get_term_id . ' item-tag-' . $get_term_slug . '"><strong class="bread-current bread-tag-' . $get_term_id . ' bread-tag-' . $get_term_slug . '">' . $get_term_name . '</strong></li>';

        } elseif (is_day()) {

            // Day archive

            // Year link
            echo '<li class="c-breadcrumb__year item-year-' . get_the_time('Y') . '"><a class="bread-year bread-year-' . get_the_time('Y') . '" href="' . get_year_link(get_the_time('Y')) . '" title="' . get_the_time('Y') . '">' . get_the_time('Y') . ' Archives</a></li>';
            echo '<li class="c-breadcrumb__separator separator-' . get_the_time('Y') . '"> ' . $separator . ' </li>';

            // Month link
            echo '<li class="c-breadcrumb__month item-month-' . get_the_time('m') . '"><a class="bread-month bread-month-' . get_the_time('m') . '" href="' . get_month_link(get_the_time('Y'), get_the_time('m')) . '" title="' . get_the_time('M') . '">' . get_the_time('M') . ' Archives</a></li>';
            echo '<li class="c-breadcrumb__separator separator-' . get_the_time('m') . '"> ' . $separator . ' </li>';

            // Day display
            echo '<li class="c-breadcrumb__current item-' . get_the_time('j') . '"><strong class="bread-current bread-' . get_the_time('j') . '"> ' . get_the_time('jS') . ' ' . get_the_time('M') . ' Archives</strong></li>';

        } else if (is_month()) {

            // Month Archive

            // Year link
            echo '<li class="c-breadcrumb__year item-year-' . get_the_time('Y') . '"><a class="bread-year bread-year-' . get_the_time('Y') . '" href="' . get_year_link(get_the_time('Y')) . '" title="' . get_the_time('Y') . '">' . get_the_time('Y') . ' Archives</a></li>';
            echo '<li class="c-breadcrumb__separator separator-' . get_the_time('Y') . '"> ' . $separator . ' </li>';

            // Month display
            echo '<li class="c-breadcrumb__month item-month-' . get_the_time('m') . '"><strong class="bread-month bread-month-' . get_the_time('m') . '" title="' . get_the_time('M') . '">' . get_the_time('M') . ' Archives</strong></li>';

        } else if (is_year()) {

            // Display year archive
            echo '<li class="c-breadcrumb__current item-current-' . get_the_time('Y') . '"><strong class="bread-current bread-current-' . get_the_time('Y') . '" title="' . get_the_time('Y') . '">' . get_the_time('Y') . ' Archives</strong></li>';

        } else if (is_author()) {

            // Auhor archive

            // Get the author information
            global $author;
            $userdata = get_userdata($author);

            // Display author name
            echo '<li class="c-breadcrumb__current item-current-' . $userdata->user_nicename . '"><strong class="bread-current bread-current-' . $userdata->user_nicename . '" title="' . $userdata->display_name . '">' . 'Author: ' . $userdata->display_name . '</strong></li>';

        } else if (get_query_var('paged')) {

            // Paginated archives
            echo '<li class="c-breadcrumb__current item-current-' . get_query_var('paged') . '"><strong class="bread-current bread-current-' . get_query_var('paged') . '" title="Page ' . get_query_var('paged') . '">' . __('Page', 'theia') . ' ' . get_query_var('paged') . '</strong></li>';

        } else if (is_search()) {

            // Search results page
            echo '<li class="c-breadcrumb__current item-current-' . get_search_query() . '"><strong class="bread-current bread-current-' . get_search_query() . '" title="Search results for: ' . get_search_query() . '">Search results for: ' . get_search_query() . '</strong></li>';

        } elseif (is_404()) {

            // 404 page
            echo '<li>' . 'Error 404' . '</li>';
        }

        echo '</ul>';

    }

}

function filter_p_tags_on_images($content)
{
    return preg_replace('/<p>\\s*?(<a .*?><img.*?><\\/a>|<img.*?>)?\\s*<\\/p>/s', '\1', $content);
}

add_filter('the_content', 'filter_p_tags_on_images');

function theia_portfolio_featured_side_meta_box() {
    add_meta_box(
        'side_fields', // $id
        'Featured project', // $title
        'theia_portfolio_featured_side_meta_box_callback', // $callback
        'portfolio', // $screen
        'side', // $context
        'high' // $priority
    );
}
add_action( 'add_meta_boxes', 'theia_portfolio_featured_side_meta_box' );

function theia_portfolio_featured_side_meta_box_callback(){
        $post_id = get_the_ID();

        if (get_post_type($post_id) != 'portfolio') {
            return;
        }

        $field_id = 'portfolio_featured';
        $field_value = esc_attr(get_post_meta($post_id, $field_id, true));
        $field_text = esc_html__('Mark as featured', 'theia');
        $field_state = checked($field_value, 1, false);

        $field_label = sprintf(
            '<div class="misc-pub-section"><label for="%1$s"><input type="checkbox" name="%1$s" id="%1$s" value="%2$s" %3$s> %4$s</label></div>',
            $field_id, $field_value, $field_state, $field_text
        );

        echo $field_label;
}


function theia_portfolio_featured_side_meta_box_save($post_ID, $post, $update)
{
    $field_id = 'portfolio_featured';
    $field_value = isset($_REQUEST[$field_id]) ? 1 : 0;

    update_post_meta($post_ID, $field_id, $field_value);

}

add_action('save_post', 'theia_portfolio_featured_side_meta_box_save', 10, 3);


//portfolio custom fields
function theia_portfolio_fields_meta_box() {
    add_meta_box(
        'portfolio_fields', // $id
        'Portfolio Fields', // $title
        'theia_portfolio_fields_meta_box_callback', // $callback
        'portfolio', // $screen
        'normal', // $context
        'high' // $priority
    );
}
add_action( 'add_meta_boxes', 'theia_portfolio_fields_meta_box' );

function theia_portfolio_fields_meta_box_callback(){
    global $post;
    $meta = get_post_meta( $post->ID, 'portfolio_fields', true ); ?>

    <input type="hidden" name="portfolio_fields_nonce" value="<?php echo wp_create_nonce( basename(__FILE__) ); ?>">

    <p>
        <label for="portfolio_fields[commissioned_by]"><?php _e('Collaboration:', 'theia') ?></label>
        <br>
        <input type="text" name="portfolio_fields[commissioned_by]" id="portfolio_fields[commissioned_by]" class="regular-text" value="<?php if (is_array($meta) && isset($meta['commissioned_by'])) {	echo $meta['commissioned_by']; } ?>">
    </p>
    <p>
        <label for="portfolio_fields[role]"><?php _e('Role:', 'theia') ?></label>
        <br>
        <input type="text" name="portfolio_fields[role]" id="portfolio_fields[role]" class="regular-text" value="<?php if (is_array($meta) && isset($meta['role'])) {	echo $meta['role']; } ?>">
    </p>
    <p>
        <label for="portfolio_fields[technic]"><?php _e('Technic:', 'theia') ?></label>
        <br>
        <input type="text" name="portfolio_fields[technic]" id="portfolio_fields[technic]" class="regular-text" value="<?php if (is_array($meta) && isset($meta['technic'])) {	echo $meta['technic']; } ?>">
    </p>
    <p>
        <label for="portfolio_fields[place]"><?php _e('Place:', 'theia') ?></label>
        <br>
        <input type="text" name="portfolio_fields[place]" id="portfolio_fields[place]" class="regular-text" value="<?php if (is_array($meta) && isset($meta['place'])) {	echo $meta['place']; } ?>">
    </p>
    <p>
        <label for="portfolio_fields[year]"><?php _e('Year:', 'theia') ?></label>
        <br>
        <input type="text" name="portfolio_fields[year]" id="portfolio_fields[year]" class="regular-text" value="<?php if (is_array($meta) && isset($meta['year'])) {	echo $meta['year']; } ?>">
    </p>
    <p>
        <label for="portfolio_fields[awards]"><?php _e('Awards:', 'theia') ?></label>
        <br>
        <input type="text" name="portfolio_fields[awards]" id="portfolio_fields[awards]" class="regular-text" value="<?php if (is_array($meta) && isset($meta['awards'])) {	echo $meta['awards']; } ?>">
    </p>
    <?php
}

function theia_portfolio_fields_meta_box_save( $post_id ) {
    // verify nonce
    if ( isset($_POST['portfolio_fields_nonce'])
        && !wp_verify_nonce( $_POST['portfolio_fields_nonce'], basename(__FILE__) ) ) {
        return $post_id;
    }
    // check autosave
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return $post_id;
    }
    // check permissions
    if (isset($_POST['portfolio'])) { //Fix 2
        if ( 'page' === $_POST['portfolio'] ) {
            if ( !current_user_can( 'edit_page', $post_id ) ) {
                return $post_id;
            } elseif ( !current_user_can( 'edit_post', $post_id ) ) {
                return $post_id;
            }
        }
    }

    $old = get_post_meta( $post_id, 'portfolio_fields', true );
    if (isset($_POST['portfolio_fields'])) { //Fix 3
        $new = $_POST['portfolio_fields'];
        if ( $new && $new !== $old ) {
            update_post_meta( $post_id, 'portfolio_fields', $new );
        } elseif ( '' === $new && $old ) {
            delete_post_meta( $post_id, 'portfolio_fields', $old );
        }
    }
}

add_action( 'save_post', 'theia_portfolio_fields_meta_box_save' );

//custom posts per page for portfolio archive

function theia_portfolio_archive_posts_per_page( $query ) {
    if ( is_admin() || ! $query->is_main_query() ) {
        return;
    }

    $posts_per_page = theia_option('portfolio_archive_posts_per_page');
    $order = theia_option('portfolio_archive_order');
    $orderby = theia_option('portfolio_archive_orderby');

    if(empty($posts_per_page)){
        return;
    }

    if ( is_post_type_archive( 'portfolio' ) || is_tax('portfolio-categories') || is_tax('portfolio-tags')) {
        $query->set( 'posts_per_page', $posts_per_page );
        $query->set( 'order', $order );
        $query->set( 'orderby', $orderby );
    }

}
add_filter( 'pre_get_posts', 'theia_portfolio_archive_posts_per_page' );
