<?php
/**
 * The template for displaying archive pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package THEIA
 */

get_header();
?>

    <div id="primary" class="u-blog-background">
        <main id="main" class="u-content-top-spacing u-content-bottom-spacing">
            <div class="u-container-sides-spacing">
                <div class="o-wrapper u-container-width">
                    <div class="o-layout__page">
                        <?php if (have_posts()) : ?>

                        <header class="c-page-header u-content-bottom-spacing">
                            <h1 class="c-page-header__title"><?php _e( 'Portfolio', 'theia' ); ?></h1>
                            <?php
                            the_archive_description('<div class="c-page-header__description">', '</div>');
                            ?>
                        </header>
                        <div class="c-grid c-grid--full">
                            <div class="c-grid__layout">
                                <?php
                                while (have_posts()) :
                                    the_post();

                                    get_template_part('template-parts/content-item-portfolio');

                                endwhile;

                                theia_numeric_posts_nav();

                                else :

                                    get_template_part('template-parts/content', 'none');

                                endif;
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
        </main>
    </div>

<?php
get_footer();
