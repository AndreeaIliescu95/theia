<?php
/**
 * Template Name: Page no title
 * The template for displaying page with no title.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package THEIA
 */

get_header();
?>

    <div id="primary" class="u-content-background">
        <main id="main" class="u-content-top-spacing u-content-bottom-spacing">
            <div class="u-container-sides-spacing">
                <div class="o-wrapper u-container-width">
                    <div class="o-layout__page">
                        <?php
                        while (have_posts()) :
                            the_post();

                            get_template_part('template-parts/content', 'page-notitle');

                            if (comments_open() || get_comments_number()) :
                                comments_template();
                            endif;

                        endwhile;
                        ?>
                    </div>
                </div>
            </div>
        </main><!-- #main -->
    </div><!-- #primary -->
<?php
get_footer();
