<?php
function better_comments($comment, $args, $depth)
{
    global $post;
    $author_id = $post->post_author;
    $GLOBALS['comment'] = $comment;
    switch ($comment->comment_type) :
        case 'pingback' :
        case 'trackback' :
            // Display trackbacks differently than normal comments.
            ?>
            <li id="comment-<?php comment_ID(); ?>" <?php comment_class(); ?>>
            <div class="pingback-entry"><span
                        class="pingback-heading"><?php esc_html_e('Pingback:', 'theia'); ?></span> <?php comment_author_link(); ?>
            </div>
            <?php
            break;
        default :
            // Proceed with normal comments.
            ?>
        <li class="c-comments__zone" id="li-comment-<?php comment_ID(); ?>">
            <article id="comment-<?php comment_ID(); ?>" <?php comment_class('c-comments__comment clr'); ?>>
                <div class="c-comments__author comment-author vcard">
                    <?php echo get_avatar($comment, 80); ?>
                </div><!-- .comment-author -->
                <div class="c-comments__body">
                    <div class="c-comments__meta">
                        <div class="c-comments__name fn"><?php comment_author_link(); ?></div>
                        <div class="c-comments__date">
                            <?php printf('<a href="%1$s"><time datetime="%2$s">%3$s</time></a>',
                                esc_url(get_comment_link($comment->comment_ID)),
                                get_comment_time('c'),
                                sprintf(_x('%1$s', '1: date', 'theia'), get_comment_date())
                            ); ?>
                        </div><!-- .comment-date -->
                    </div><!-- .comment-meta -->
                    <div class="c-comments__details clr">

                        <?php if ('0' == $comment->comment_approved) : ?>
                            <p class="c-comments__moderation"><?php esc_html_e('Your comment is awaiting moderation.', 'theia'); ?></p>
                        <?php endif; ?>
                        <div class="c-comments__content clr">
                            <?php comment_text(); ?>
                            <div class="c-comments__reply reply comment-reply-link">
                                <?php comment_reply_link(array_merge($args, array(
                                        'reply_text' => esc_html__('Reply', 'theia'),
                                        'depth' => $depth,
                                        'max_depth' => $args['max_depth'])
                                )); ?>
                            </div><!-- .reply -->
                        </div><!-- .comment-content -->
                </div>

                </div><!-- .comment-details -->
            </article><!-- #comment-## -->
            <?php
            break;
    endswitch; // End comment_type check.
}