<?php

/**
 * Add Active Menu
 */

function special_nav_class($classes, $item)
{
    if (in_array('current-menu-item', $classes)) {
        $classes[] = 'active ';
    }
    return $classes;
}
add_filter('nav_menu_css_class', 'special_nav_class', 10, 2);

/**
 * Material Icons via Google API
 */

function wpb_add_material_icons()
{

    wp_enqueue_style('wpb-material-icons', 'https://fonts.googleapis.com/icon?family=Material+Icons', false);
}

add_action('wp_enqueue_scripts', 'wpb_add_material_icons');

/**
 * Add preconnect for Google Fonts.
 *
 * @since Theia 1.0
 *
 * @param array $urls URLs to print for resource hints.
 * @param string $relation_type The relation type the URLs are printed.
 * @return array $urls           URLs to print for resource hints.
 */
function theia_resource_hints($urls, $relation_type)
{
    if (wp_style_is('theia-fonts', 'queue') && 'preconnect' === $relation_type) {
        $urls[] = array(
            'href' => 'https://fonts.gstatic.com',
            'crossorigin',
        );
    }

    return $urls;
}

function theia_fonts_url() {
    $fonts_url = '';
    /**
     * Translators: If there are characters in your language that are not
     * supported by Open Sans, translate this to 'off'. Do not translate
     * into your own language.
     */
    $open_sans = _x( 'on', 'Open Sans font: on or off', 'theia' );
    if ( 'off' !== $open_sans ) {
        $font_families = array();
        $font_families[] = 'Open Sans:300,400,600,700,800|Oswald:400,500';
        $query_args = array(
            'family' => urlencode( implode( '|', $font_families ) ),
            'subset' => urlencode( 'latin,latin-ext' ),
        );
        $fonts_url = add_query_arg( $query_args, 'https://fonts.googleapis.com/css' );
    }
    return esc_url_raw( $fonts_url );
}

add_filter('wp_resource_hints', 'theia_resource_hints', 10, 2);

/**
 * Filter excerpt length to 20 words
 */

function theia_custom_excerpt_length($length)
{
    return 20;
}

add_filter('excerpt_length', 'theia_custom_excerpt_length', 999);

/**
 * Image orientation
 */

function renderOrientation($key, $orientation)
{
    if (has_post_thumbnail()) {

        if ($key && $key !== '') {

            if ($orientation) {
                $imgID = get_post_thumbnail_id();
                $img = wp_get_attachment_image_src($imgID, 'full');
                $width = $img[1];
                $height = $img[2];

                if ($width > $height) {
                    $_orientation = 'landscape';
                    $size = $key . '-' . $_orientation;
                } else {
                    $_orientation = 'portrait';
                    $size = $key . '-' . $_orientation;
                }
            } else {
                $size = $key;
            }
        } else {
            $size = 'full';
        }
        the_post_thumbnail($size, array('class' => " size-" . $size));
    }
}

function merlin_local_import_files()
{
    return array(
        array(
            'import_file_name' => 'Demo Import',
            'local_import_file' => get_parent_theme_file_path('/inc/demo/content.xml'),
            'local_import_widget_file' => get_parent_theme_file_path('/inc/demo/widgets.wie'),
            'local_import_customizer_file' => get_parent_theme_file_path('/inc/demo/customizer.dat'),
            'import_preview_image_url' => 'http://www.your_domain.com/merlin/preview_import_image1.jpg',
            'import_notice' => __('A special note for this import.', 'theia'),
            'preview_url' => 'http://www.your_domain.com/my-demo-1',
        ),
    );
}

add_filter('merlin_import_files', 'merlin_local_import_files');

function theia_option($option, $default = null, $force_default = true)
{
    /** @var PixCustomifyPlugin $pixcustomify_plugin */
    global $pixcustomify_plugin;

    if ($pixcustomify_plugin !== null) {
        // if there is a customify value get it here

        // First we see if we are not supposed to force over the option's default value
        if ($default !== null && $force_default == false) {
            // We will not pass the default here so Customify will fallback on the option's default value, if set
            $customify_value = $pixcustomify_plugin->get_option($option);

            // We only fallback on the $default if none was given from Customify
            if ($customify_value == null) {
                return $default;
            }
        } else {
            $customify_value = $pixcustomify_plugin->get_option($option, $default);
        }
        
        return $customify_value;
    }

    return $default;
}
function theia_get_attachment_image_src( $id, $size = null ) {
    //bail if not given an attachment id
    if ( empty( $id ) || ! is_numeric( $id ) ) {
        return false;
    }

    $array = wp_get_attachment_image_src( $id, $size );

    if ( isset( $array[0] ) ) {
        return $array[0];
    }

    return false;
}
function theia_image_src( $target, $size = null ) {
    if ( isset( $_GET[ $target ] ) && ! empty( $target ) ) {
        return theia_get_attachment_image_src( $_GET[ $target ], $size );
    } else { // empty target, or no query
        $image = theia_option( $target );
        if ( is_numeric( $image ) ) {
            return theia_get_attachment_image_src( $image, $size );
        }
    }

    return false;
}

/**
 * Load custom javascript set by theme options
 */
function theia_callback_load_custom_js() {
    $custom_js = theia_option( 'header_custom_js' );
    if ( ! empty( $custom_js ) ) {
        //first lets test is the js code is clean or has <script> tags and such
        //if we have <script> tags than we will not enclose it in anything - raw output
        if ( strpos( $custom_js, '</script>' ) !== false ) {
            echo $custom_js . "\n";
        } else {
            echo "<script>\n(function($){\n" . $custom_js . "\n})(jQuery);\n</script>\n";
        }
    }
}

// custom javascript handlers - make sure it is the last one added
add_action( 'wp_head', 'theia_callback_load_custom_js', 999 );

function theia_callback_load_custom_js_footer() {
    $custom_js = theia_option( 'footer_custom_js' );
    if ( ! empty( $custom_js ) ) {
        //first lets test is the js code is clean or has <script> tags and such
        //if we have <script> tags than we will not enclose it in anything - raw output
        if ( strpos( $custom_js, '</script>' ) !== false ) {
            echo $custom_js . "\n";
        } else {
            echo "<script>\n(function($){\n" . $custom_js . "\n})(jQuery);\n</script>\n";
        }
    }
}

add_action( 'wp_footer', 'theia_callback_load_custom_js_footer', 999 );