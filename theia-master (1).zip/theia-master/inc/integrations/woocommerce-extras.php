<?php
/**
 * Disable Woocommerce default style
 */
add_filter('woocommerce_enqueue_styles', '__return_empty_array');

/**
 * Opening div for our content wrapper
 */
add_action('woocommerce_before_main_content', 'theia_open_div', 15);

function theia_open_div()
{
    ?>
    <div class="u-container-sides-spacing">
    <div class="o-wrapper u-container-width">
    <div class="o-layout__shop">
    <?php
}

/**
 * Closing div for our content wrapper
 */
add_action('woocommerce_after_main_content', 'theia_close_div', 50);

function theia_close_div()
{
    ?>
    </div>
    </div>
    </div>
    <?php
}

//Reposition WooCommerce breadcrumb
function woocommerce_remove_breadcrumb()
{
    remove_action('woocommerce_before_main_content', 'woocommerce_breadcrumb', 20);
}

add_action('woocommerce_before_main_content', 'woocommerce_remove_breadcrumb');

function woocommerce_custom_breadcrumb()
{
    woocommerce_breadcrumb();
}

add_action('woo_custom_breadcrumb', 'woocommerce_custom_breadcrumb');

// Remove the result count from WooCommerce
remove_action('woocommerce_before_shop_loop', 'woocommerce_result_count', 20);

// remove default sorting dropdown
remove_action('woocommerce_before_shop_loop', 'woocommerce_catalog_ordering', 30);


function woocommerce_custom_catalog_ordering()
{
    woocommerce_catalog_ordering();
}

add_action('woo_custom_catalog_ordering', 'woocommerce_custom_catalog_ordering');

// remove pagination
remove_action('woocommerce_after_shop_loop', 'woocommerce_pagination', 10);

function woocommerce_custom_pagination()
{
    woocommerce_pagination();
}

add_action('woo_custom_pagination', 'woocommerce_custom_pagination');
//END


// First remove default wrapper
remove_action('woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10);
remove_action('woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10);

// remove woocommerce_show_product_loop_sale_flash
remove_action('woocommerce_before_shop_loop_item_title', 'woocommerce_show_product_loop_sale_flash', 10);

// remove woocommerce_template_loop_add_to_cart
remove_action('woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart', 10);


/**
 * Get My Account menu items.
 *
 * @since 2.6.0
 * @return array
 */
add_filter('woocommerce_account_menu_items', 'custom_woocommerce_account_menu_items');
function custom_woocommerce_account_menu_items($items)
{
    if (isset($items['dashboard'])) unset($items['dashboard']);
    return $items;
}

/*
 * Get My Account menu items.
 *
 * @since 2.6.0
 * @return array
 */
function sv_remove_cart_product_link($product_link, $cart_item, $cart_item_key)
{
    $product = apply_filters('woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key);
    return $product->get_title();
}

add_filter('woocommerce_cart_item_thumbnail', '__return_false');


// Hook in
add_filter('woocommerce_checkout_fields', 'custom_override_checkout_fields');

// Our hooked in function - $fields is passed via the filter!
function custom_override_checkout_fields($fields)
{
//    $fields['order']['order_comments']['placeholder'] = 'Aditional notes for your order *';
//    $fields['billing']['billing_first_name']['placeholder'] = 'First name *';
//    $fields['billing']['billing_last_name']['placeholder'] = 'Last name *';
//    $fields['billing']['billing_company']['placeholder'] = 'Company name';
//    $fields['billing']['billing_address_1']['placeholder'] = 'Street adress ex: street name, street number, apartment, suite etc*';
//    $fields['billing']['billing_address_2']['placeholder'] = 'My new placeholder';
//    $fields['billing']['billing_city']['placeholder'] = 'Town / City *';
//    $fields['billing']['billing_postcode']['placeholder'] = 'Zip *';
//    $fields['billing']['billing_phone']['placeholder'] = 'Phone number *';
//    $fields['billing']['billing_email']['placeholder'] = 'Email*';
//    $fields['billing']['billing_state']['placeholder'] = 'State *';
    unset($fields['billing']['billing_county']);
    unset($fields['billing']['billing_address_2']);


    return $fields;
}


add_filter('woocommerce_checkout_get_value', '__return_empty_string', 1, 1);

function theia_get_img_alt( $image ) {
    $img_alt = trim( strip_tags( get_post_meta( $image, '_wp_attachment_image_alt', true ) ) );

    return $img_alt;
}

function theia_woocommerce_template_loop_product_link_open() {
    echo '<a href="' . get_the_permalink() . '" class="c-grid__link">';
}

remove_action( 'woocommerce_before_shop_loop_item', 'woocommerce_template_loop_product_link_open', 10 );
add_action( 'woocommerce_before_shop_loop_item', 'theia_woocommerce_template_loop_product_link_open', 10 );

remove_action('woocommerce_single_product_summary', 'woocommerce_template_single_meta', 40);

add_action ('woocommerce_single_product_summary', 'woocommerce_template_single_meta', 0);
add_filter('woocommerce_product_description_heading', '__return_null');
add_filter('woocommerce_product_additional_information_heading', '__return_null');

/* Remove rating on loop */
remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_rating', 5 );

/* Remove Woocommerce lightbox */
add_action( 'after_setup_theme', 'remove_wc_gallery_lightbox', 100 );
function remove_wc_gallery_lightbox() {
    remove_theme_support( 'wc-product-gallery-lightbox' );
}

function disable_woo_commerce_sidebar() {
    remove_action( 'woocommerce_sidebar', 'woocommerce_get_sidebar', 10);
}
add_action('init', 'disable_woo_commerce_sidebar');