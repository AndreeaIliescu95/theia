<?php

/**
 * This filter is used to change the Customizer Options
 * You can also copy this function inside your functions.php
 * file but DO NOT FORGET TO CHANGE ITS NAME
 *
 * @param $config array This holds required keys for the plugin config like 'opt-name', 'panels', 'settings'
 * @return $config
 */


if (!function_exists('add_customify_theia_options')) {

    function add_customify_theia_options($config)
    {
        $recommended_headings_fonts = array(
            'Oswald'
        );

        $recommended_body_fonts = array(
            'Open Sans',
        );

        $config['opt-name'] = 'theia_options';

        $config['sections'] = array(

            'general' => array(
                'title' => '&#x1f506; &nbsp;&nbsp;' . esc_html__('General', 'theia'),
                'priority' => 0,
                'options' => array(
                    'this_divider_2937811333' => array(
                        'type' => 'html',
                        'html' => '<span id="section-title-header-colors" class="separator section label large">' . esc_html__('Sharing', 'theia') . '</span>',
                    ),
                    'share_buttons_settings' => array(
                        'type' => 'text',
                        'default' => 'facebook,twitter,google_plus',
                        'label' => esc_html__('Sharing Services', 'theia'),
                        'desc' => __('<p>Add the share services, delimited by a single comma (no spaces).</p>
								Share services:
								<ul>
								<li>- facebook</li>
								<li>- twitter</li>
								<li>- google_plus</li>
								<li>- pinterest</li>
								<li>- linkedin</li>
								<li>- tumblr</li>
								<li>- digg</li>
								<li>- email</li>
								</ul>', 'theia'),
                    ),
                    'this_divider_2937811371' => array(
                        'type' => 'html',
                        'html' => '<span id="section-title-header-colors" class="separator section label large">' . esc_html__('Custom Javascript', 'theia') . '</span>',
                    ),
                    'header_custom_js' => array(
                        'type' => 'ace_editor',
                        'label' => esc_html__('Header', 'theia'),
                        'desc' => esc_html__('Easily add Custom Javascript code. This code will be loaded in the <head> section.', 'theia'),
                        'editor_type' => 'javascript',
                    ),
                    'footer_custom_js' => array(
                        'type' => 'ace_editor',
                        'label' => esc_html__('Footer', 'theia'),
                        'desc' => esc_html__('You can paste here your Google Analytics tracking code (or for what matters any tracking code) and we will put it on every page.', 'theia'),
                        'editor_type' => 'javascript',
                    ),
                    'this_divider_2937811171' => array(
                        'type' => 'html',
                        'html' => '<span id="section-title-header-colors" class="separator section label large">' . esc_html__('Copyright', 'theia') . '</span>',
                    ),
                    'copyright_text' => array(
                        'type' => 'textarea',
                        'label' => esc_html__('Copyright Text', 'theia'),
                        'default' => __('© 2018 THEIA. All rights reserved | Handcrafted with <img draggable="false" class="emoji" alt="😍" src="https://s.w.org/images/core/emoji/2.4/svg/1f60d.svg"> by <a href="https://acidstudios.ro" target="_blank">Acid Studios</a> Team.', 'theia'),
                        'sanitize_callback' => 'wp_kses_post',
                        'live' => array('.copyright-text'),
                    ),
                )
            ),

            'hero_area' => array(
                'title' => '&#9969; &nbsp;&nbsp;' . esc_html__('Hero Area', 'theia'),
                'priority' => 1,
                'options' => array(
                    'this_divider_2934812317' => array(
                        'type' => 'html',
                        'html' => '<span id="section-title-header-colors" class="separator section label large">' . esc_html__('General', 'theia') . '</span>',
                    ),
                    'active_autoplay' => array(
                        'type' => 'checkbox',
                        'label' => esc_html__('Enable Slider Autoplay', 'theia'),
                        'default' => true,
                    ),
                    'autoplay_speed' => array(
                        'type' => 'range',
                        'label' => esc_html__('Autoplay transition speed', 'theia'),
                        'desc' => esc_html__('Select slide trasition timeout.', 'theia'),
                        'default' => 5000,
                        'input_attrs' => array(
                            'min' => 1000,
                            'max' => 10000,
                            'step' => 1000
                        ),
                    ),
                    'overlay_darkness' => array(
                        'type' => 'range',
                        'label' => esc_html__('Overlay Darkness', 'theia'),
                        'default' => 0,
                        'live' => true,
                        'input_attrs' => array(
                            'min' => 0,
                            'max' => 1,
                            'step' => 0.01
                        ),
                        'css' => array(
                            array(
                                'property' => 'opacity',
                                'selector' => '.c-hero__slider-overlay',
                                'unit' => '',
                            ),
                        ),
                    ),
                    'this_divider_2934842317' => array(
                        'type' => 'html',
                        'html' => '<span id="section-title-header-colors" class="separator section label large">' . esc_html__('Animations', 'theia') . '</span>',
                    ),
                    'active_animation' => array(
                        'type' => 'checkbox',
                        'label' => esc_html__('Enable Slider Animation', 'theia'),
                        'default' => true,
                    ),
                    'animation_speed' => array(
                        'type' => 'select',
                        'label' => esc_html__('Slider Effect Animation', 'theia'),
                        'desc' => esc_html__('Select slider animation speed', 'theia'),
                        'choices' => array(
                            'slow' => 'Slow',
                            'medium' => 'Medium',
                            'fast' => 'Fast'
                        ),
                        'default' => 'medium',
                    ),
                    'transition_speed' => array(
                        'type' => 'select',
                        'label' => esc_html__('Slider Transition Speed', 'theia'),
                        'desc' => esc_html__('Select slider transition distorsion speed', 'theia'),
                        'choices' => array(
                            'minor' => 'Minor',
                            'medium' => 'Medium',
                            'major' => 'Major'
                        ),
                        'default' => 'medium',
                    ),
                    'distorsion_scale' => array(
                        'type' => 'select',
                        'label' => esc_html__('Slider Distorsion Scale', 'theia'),
                        'desc' => esc_html__('Select slider distorsion scale', 'theia'),
                        'choices' => array(
                            '2048x2048' => 'Small',
                            '512x512' => 'Big'
                        ),
                        'default' => '2048x2048',
                    ),
                    'distorsion_effect' => array(
                        'type' => 'select',
                        'label' => esc_html__('Slider Distorsion Effect', 'theia'),
                        'desc' => esc_html__('Select slider distorsion effect', 'theia'),
                        'choices' => array(
                            'clouds' => 'Clouds',
                            'crystalize' => 'Crystalize',
                            'fibers' => 'Fibers',
                            'pointilize' => 'Pointilize',
                            'ripple' => 'Ripple',
                            'ripple_2' => 'Ripple 2'
                        ),
                        'default' => 'clouds',
                    ),
                    'this_divider_2934812117' => array(
                        'type' => 'html',
                        'html' => '<span id="section-title-header-colors" class="separator section label large">' . esc_html__('Elements', 'theia') . '</span>',
                    ),
                    'active_title' => array(
                        'type' => 'checkbox',
                        'label' => esc_html__('Enable Title', 'theia'),
                        'default' => true,
                    ),
                    'active_scroll_down' => array(
                        'type' => 'checkbox',
                        'label' => esc_html__('Enable Scroll Down Trigger', 'theia'),
                        'default' => true,
                    ),
                    'active_bullets' => array(
                        'type' => 'checkbox',
                        'label' => esc_html__('Enable Bullets', 'theia'),
                        'default' => true,
                    ),
                    'active_keyboard_nav' => array(
                        'type' => 'checkbox',
                        'label' => esc_html__('Enable Slider Keyboard Navigation', 'theia'),
                        'default' => true,
                    ),
                    'active_view_project' => array(
                        'type' => 'checkbox',
                        'label' => esc_html__('Enable View Project Button', 'theia'),
                        'default' => true,
                    ),
                    'view_project_text' => array(
                        'type' => 'text',
                        'label' => esc_html__('View Project Button Text', 'theia'),
                        'default' => esc_html__('Explore', 'theia'),
                    )
                ),
            ),

            'portfolio_archive' => array(
                'title' => '&#128444; &nbsp;&nbsp;' . esc_html__('Portfolio Archive', 'theia'),
                'priority' => 2,
                'options' => array(
                    'this_divider_2931817333' => array(
                        'type' => 'html',
                        'html' => '<span id="section-title-header-colors" class="separator section label large">' . esc_html__('Front Page Featured Projects', 'theia') . '</span>',
                    ),
                    'portfolio_featured_posts_per_page' => array(
                        'type' => 'range',
                        'label' => esc_html__('Portfolio projects', 'theia'),
                        'desc' => esc_html__('Select how many projects you want to be shown.', 'theia'),
                        'default' => 6,
                        'input_attrs' => array(
                            'min' => 1,
                            'max' => 12,
                            'step' => 1
                        ),
                    ),
                    'portfolio_featured_order' => array(
                        'type' => 'select',
                        'label' => esc_html__('Projects order', 'theia'),
                        'desc' => esc_html__('Select the order of portfolio projects.', 'theia'),
                        'choices' => array(
                            'asc' => 'Ascendant',
                            'desc' => 'Descendant',
                        ),
                        'default' => 'desc',
                    ),
                    'portfolio_featured_orderby' => array(
                        'type' => 'select',
                        'label' => esc_html__('Order projects by:', 'theia'),
                        'choices' => array(
                            'ID' => 'ID',
                            'title' => 'Title',
                            'date' => 'Date',
                            'modified' => 'Modified',
                            'rand' => 'Random'
                        ),
                        'default' => 'ID',
                    ),
                    'this_divider_2931811333' => array(
                        'type' => 'html',
                        'html' => '<span id="section-title-header-colors" class="separator section label large">' . esc_html__('Portfolio Archive', 'theia') . '</span>',
                    ),
                    'portfolio_archive_posts_per_page' => array(
                        'type' => 'range',
                        'label' => esc_html__('Portfolio projects', 'theia'),
                        'desc' => esc_html__('Select how many projects you want to be shown.', 'theia'),
                        'default' => 6,
                        'input_attrs' => array(
                            'min' => 1,
                            'max' => 12,
                            'step' => 1
                        ),
                    ),
                    'portfolio_archive_order' => array(
                        'type' => 'select',
                        'label' => esc_html__('Projects order', 'theia'),
                        'desc' => esc_html__('Select the order of portfolio projects.', 'theia'),
                        'choices' => array(
                            'asc' => 'Ascendant',
                            'desc' => 'Descendant',
                        ),
                        'default' => 'desc',
                    ),
                    'portfolio_archive_orderby' => array(
                        'type' => 'select',
                        'label' => esc_html__('Order projects by:', 'theia'),
                        'choices' => array(
                            'ID' => 'ID',
                            'title' => 'Title',
                            'date' => 'Date',
                            'modified' => 'Modified',
                            'rand' => 'Random'
                        ),
                        'default' => 'ID',
                    ),
                )
            ),

            'blog' => array(
                'title' => '&#x1f4d4; &nbsp;&nbsp;' . esc_html__('Blog', 'theia'),
                'priority' => 3,
                'options' => array(
                    'this_divider_2931861333' => array(
                        'type' => 'html',
                        'html' => '<span id="section-title-header-colors" class="separator section label large">' . esc_html__('Blog Archive', 'theia') . '</span>',
                    ),
                    'active_inverted_image' => array(
                        'type' => 'checkbox',
                        'label' => esc_html__('Enable Inverted Image', 'theia'),
                        'default' => true,
                    ),
                    'blog_navigation' => array(
                        'type' => 'select',
                        'label' => esc_html__('Blog Navigation', 'theia'),
                        'desc' => esc_html__('Select the type of blog navigation', 'theia'),
                        'choices' => array(
                            'paged' => 'Paged',
                            'infinite_scroll' => 'Infinite Scroll',
                            'load_more' => 'Load More Button'
                        ),
                        'default' => 'paged',
                    ),
                    'this_divider_2931841333' => array(
                        'type' => 'html',
                        'html' => '<span id="section-title-header-colors" class="separator section label large">' . esc_html__('Single Post', 'theia') . '</span>',
                    ),
                    'active_related_posts' => array(
                        'type' => 'checkbox',
                        'label' => esc_html__('Enable Related Posts', 'theia'),
                        'default' => true,
                    ),
                    'active_author_box' => array(
                        'type' => 'checkbox',
                        'label' => esc_html__('Enable Author Box', 'theia'),
                        'default' => true,
                    ),

                ),
            ),

            'presets_section' => array(
                'title' => '&#128374; &nbsp;&nbsp;' . esc_html__('Style Presets', 'theia'),
                'priority' => 4,
                'options' => array(
                    'theme_style' => array(
                        'type' => 'preset',
                        'label' => __('Select a style:', 'customify'),
                        'desc' => __('Conveniently change the design of your site with built-in style presets. Easy as pie.', 'customify'),
                        'default' => 'light',
                        'choices_type' => 'awesome',
                        'choices' => array(
                            'light' => array(
                                'label' => __('White Sensation', 'customify'),
                                'preview' => array(
                                    'color-text' => '#000000',
                                    'background-card' => '#ffffff',
                                    'background-label' => '#000000',
                                    'font-main' => 'Oswald',
                                    'font-alt' => 'Open Sans',
                                ),
                                'options' => array(
                                    'main_color' => '#CA4F14',
                                    'text_color' => '#484C5D',
                                    'background_color' => '#ffffff',
                                    'headings_color' => '#484C5D',
                                    'links_color' => '#CA4F14',
                                    'overlay_color' => '#ffffff',
                                    'header_color' => '#FFFFFF',
                                    'hover_color' => '#00CAB9',
                                    'blog_cards_color' => '#F5f5f5',
                                )
                            ),
                            'dark' => array(
                                'label' => __('Dark Emotion', 'customify'),
                                'preview' => array(
                                    'color-text' => '#ffffff',
                                    'background-card' => '#000000',
                                    'background-label' => '#ffffff',
                                    'font-main' => 'Oswald',
                                    'font-alt' => 'Open Sans',
                                ),
                                'options' => array(
                                    'main_color' => '#bb98ff',
                                    'text_color' => '#dadada',
                                    'background_color' => '#000000',
                                    'headings_color' => '#dadada',
                                    'links_color' => '#bb98ff',
                                    'overlay_color' => '#000000',
                                    'header_color' => '#000000',
                                    'hover_color' => '#FFFD55',
                                    'blog_cards_color' => '#0e0e0e',
                                )
                            ),
                        )
                    ),
                )
            ),

            'colors_section' => array(
                'title' => '&#x1f3a8; &nbsp;&nbsp;' . esc_html__('Colors', 'theia'),
                'priority' => 5,
                'options' => array(
                    'this_divider_2937812369' => array(
                        'type' => 'html',
                        'html' => '<span id="section-title-header-colors" class="separator section label large">' . esc_html__('Main Colors', 'theia') . '</span>',
                    ),
                    'main_color' => array(
                        'type' => 'color',
                        'label' => esc_html__('Accent Color', 'theia'),
                        //'desc'   => __( 'Use the color picker to change the main color of the site to match your brand color.', 'theia' ),
                        'live' => true,
                        'default' => '#CA4F14',
                        'css' => array(
                            array(
                                'property' => 'color',
                                'selector' => 'a, h1:not(.c-hero__title):not(.c-branding__title):not(.u-portfolio-title), .c-footer__widgets .widget-title, [class*="menu-social-menu"] a:before, button.c-btn__filter--active, .c-btn__filter:hover, [class*="home"] h1:not(.c-hero__title):not(.c-branding__title):not(.u-portfolio-title), [class*="home"] h2, [class*="home"] h3, [class*="home"] h4, [class*="home"] h5, [class*="home"] h6, .c-navbar__overlay--widget .widget-title, .c-grid__metas--field span, .c-social__text i, .glitch:before, .glitch:after, .c-btn__hero:hover, .c-grid__metas--field .field-title, .c-comments__name a, .c-loader span, .c-product__price, .c-product__title, .c-checkout__form h4, .c-social__text svg',
                            ),
                            array(
                                'property' => 'background',
                                'selector' => '.more-projects, .c-navbar__hamburger--button.active:hover span, .c-category a, .c-related__overlay, .c-header--sticky .c-navbar__cart-icon span.side-cart__number.js-side-cart-number, .c-checkout__payment_methods input[type="radio"]:checked, ::selection, .onsale',
                            ),
                            array(
                                'property' => 'background-color',
                                'selector' => '.comment-respond input[type="submit"], .c-product__cart button, .c-notices__message a, .c-cart__checkout-button, .c-cart__coupon input[type=submit], .c-checkout__place-order button, .select2-container--default .select2-results__option--highlighted[aria-selected], .select2-container--default .select2-results__option--highlighted[data-selected], .woocommerce-noreviews, .c-my-account__button, .c-my-account__login .c-btn_accent, .button, .c-checkout__coupon button, input[type="submit"], .c-cart__coupon-wrapper .button, .marker, .c-cart__parent .c-notices__info, .c-product__grouped button, .search-form input[type="submit"], .c-btn__notfound'
                            ),
                            array(
                                'property' => 'border-color',
                                'selector' => '.c-navigation__numbers-active, .c-product__variation-table select, .c-product__cart > div:first-of-type input[type=number], .c-product__tabs-list, .c-product__tabs-list li.active, .orderby, .c-navigation .page-numbers.current, select:focus, select:active',
                            ),
                            array(
                                'property' => 'border-left-color',
                                'selector' => '.cart-widget-details .wc-forward.checkout:hover:after',
                            ),
                            array(
                                'property' => 'outline-color',
                                'selector' => 'select:focus, textarea:focus, input[type="text"]:focus,
											input[type="password"]:focus, input[type="datetime"]:focus,
											input[type="datetime-local"]:focus, input[type="date"]:focus,
											input[type="month"]:focus, input[type="time"]:focus, input[type="week"]:focus,
											input[type="number"]:focus, input[type="email"]:focus, input[type="url"]:focus,
											input[type="search"]:focus, input[type="tel"]:focus, input[type="color"]:focus,
											.form-control:focus',
                            ),
                        ),
                    ),
                    'background_color' => array(
                        'type' => 'color',
                        'label' => esc_html__('Background Color', 'theia'),
                        'live' => true,
                        'default' => '#ffffff',
                        'css' => array(
                            array(
                                'property' => 'background',
                                'selector' => 'body, .u-content-background, .sticky, .u-blog-background, .c-loader, .chocolat-overlay, .c-navbar__hamburger, .c-navbar__search, .site-content, .sticky, blockquote:after, .orderby'
                            ),
                            array(
                                'property' => 'background-color',
                                'selector' => '.site-content, .select2-dropdown'
                            ),
                            array(
                                'property' => 'color',
                                'selector' => '.c-product__cart button, .c-product__cart button:hover, .c-notices__message, .c-notices__message a, .c-notices__message a:hover, .c-cart__checkout-button, .c-cart__checkout-button:hover, .c-cart__coupon-wrapper .button, .c-cart__coupon input[type=submit]:hover, .c-cart__coupon input[type=submit], .c-checkout__place-order button, .c-checkout__place-order button:hover, .woocommerce-noreviews, .c-comments-toggle__label, .c-my-account__button, c-my-account__button:hover, .c-my-account__login .c-btn_accent, .c-my-account__login .c-btn_accent:hover, .button:hover, .button, .c-checkout__coupon button, .c-checkout__coupon button:hover, input[type="submit"], input[type="submit"]:hover, .comment-respond input[type="submit"], .onsale, .c-cart__parent .c-notices__info, .single_add_to_cart_button, .c-product__grouped button, .c-product__grouped button:hover, .c-btn__notfound:hover, .c-btn__notfound'
                            )
                        ),
                    ),
                    'hover_color' => array(
                        'type' => 'color',
                        'label' => esc_html__('Hover Color', 'theia'),
                        'live' => true,
                        'default' => '#00CAB9',
                        'css' => array(
                            array(
                                'property' => 'color',
                                'selector' => 'a:hover, .c-btn__filter:hover, .c-navbar__hamburger ul li a:hover, .c-navbar__hamburger ul li a:hover, .c-navbar__search-icon:hover .search-icon:before, .c-card__title a:hover, .c-btn__read:hover, .c-meta__secondary--right a:hover, .c-meta__primary .category:hover, .c-navigation li a:hover, .c-tags a:hover, .c-header.inverted .c-navbar__search-icon:hover .search-icon:before, [class*="menu-social-menu"] a:hover:before, .c-navbar__cart-icon:hover i, .c-breadcrumb a:hover, .c-navbar__cart-icon:hover svg, .chocolat-grid:hover i, .chocolat-close:hover i, .chocolat-left:hover i, .chocolat-right:hover i, .c-product__rating > div:first-of-type span:before, .c-product__tabs p.stars:hover a:before, .c-product__tabs p.stars.selected a:before, .c-related__thumb:hover .c-related__thumb-title'
                            ),
                            array(
                                'property' => 'background-color',
                                'selector' => '.button:hover, .comment-respond input[type="submit"]:hover, .c-product__cart button:hover, .c-cart__checkout-button:hover, .c-cart__coupon-wrapper .button:hover, .c-cart__coupon input[type=submit]:hover, .c-checkout__place-order button:hover, .c-my-account__button:hover, .c-my-account__login .c-btn_accent:hover, .button:hover, .c-checkout__coupon button:hover, input[type="submit"]:hover, .single_add_to_cart_button:hover, .c-product__grouped button:hover, .search-form input[type="submit"]:hover, .c-btn__notfound:hover'
                            ),
                            array(
                                'property' => 'background',
                                'selector' => '.c-navbar__search-icon:hover .search-icon:after, .c-navbar__hamburger--button:hover span, .c-navbar__hamburger--button.active:hover span, .c-navbar__search-icon.open:hover .search-icon:after, .c-navbar__search-icon.open:hover .search-icon:before, .c-category a:hover, .c-header.inverted .c-navbar__hamburger--button:hover span, .c-header.inverted .c-navbar__search-icon:hover .search-icon:after '
                            ),
                            array(
                                'property' => 'border-color',
                                'selector' => '.c-btn__read:hover'
                            )
                        ),
                    ),
                    'this_divider_2937822369' => array(
                        'type' => 'html',
                        'html' => '<span id="section-title-header-colors" class="separator section label large">' . esc_html__('Typography', 'theia') . '</span>',
                    ),
                    'text_color' => array(
                        'type' => 'color',
                        'label' => esc_html__('Body Color', 'theia'),
                        'live' => true,
                        'default' => '#484C5D',
                        'css' => array(
                            array(
                                'property' => 'color',
                                'selector' => 'body, .search-icon:before, .c-header .c-branding__title, c-branding__description, .c-btn__filter, .c-header.sticky:not([class*="inverted"]) .c-branding__description, .c-navbar__search input[type="search"], c-social__btn, .portfolio h1:not(.u-portfolio-title), .portfolio h2, .portfolio h3, .portfolio h4, .portfolio h5, .portfolio h6, .c-social__btn i, .chocolat-left, .chocolat-right, .chocolat-close, .chocolat-grid, .glitch, .c-navbar__hamburger ul li a, .c-tags a, .c-navigation li a, .c-related__thumb-excerpt p, input[type="text"], input[type="tel"], input[type="number"], input[type="date"], input[type="email"], input[type="password"], input[type="url"], input[type="search"], textarea, .c-card__title a, .c-meta__secondary--right a, .c-meta__primary .category, .c-header--sticky .c-navbar__cart-icon i, .c-breadcrumb a, .c-product__tabs-list a, .c-product__related h4, .orderby, .c-navigation .page-numbers.current, select, .c-my-account__navigation a, p.stars a:before, .c-grid__title, .c-navbar__cart-icon svg, ::selection, .c-social__btn svg, .post-navigation p.next, .post-navigation p.prev ',
                            ),
                            array(
                                'property' => 'background',
                                'selector' => '.c-navbar__hamburger--button span, .search-icon:after, .open .search-icon:before, .open .search-icon:after, .c-navbar__hamburger--button.active .top, .c-navbar__hamburger--button.active .bottom, blockquote:before, .c-header.inverted .c-navbar__hamburger--button.active span, .c-header.inverted .c-navbar__search-icon.open .search-icon:after'
                            ),
                            array(
                                'property' => 'border-color',
                                'selector' => '.c-social__btn, .blockquote--secondary, .blockquote--secondary:before, .blockquote--secondary:after',
                            ),
                            array(
                                'property' => 'background-color',
                                'selector' => '.c-notices__message, .c-comments-toggle__label',
                            )
                        ),
                    ),
                    'headings_color' => array(
                        'type' => 'color',
                        'label' => esc_html__('Headings Color', 'theia'),
                        'live' => true,
                        'default' => '#282828',
                        'css' => array(
                            array(
                                'property' => 'color',
                                'selector' => 'h1, h2, h3, h5, h6, .article-archive .article__title a, .article-archive .article__title a:hover, .c-page-header__title',
                            ),
                        ),
                    ),
                    'links_color' => array(
                        'type' => 'color',
                        'label' => esc_html__('Links Color', 'theia'),
                        'live' => true,
                        'default' => '#CA4F14',
                        'css' => array(
                            array(
                                'property' => 'color',
                                'selector' => 'a, .c-cart__parent table.shop_table td.product-name a, .c-cart__parent table.shop_table td.product-name a',
                            ),
                        ),
                    ),
                    'this_divider_2937812372' => array(
                        'type' => 'html',
                        'html' => '<span id="section-title-header-colors" class="separator section label large">' . esc_html__('Search & Menu Overlay Color', 'theia') . '</span>',
                    ),
                    'overlay_color' => array(
                        'type' => 'color',
                        'label' => esc_html__('Overlay Background Color', 'theia'),
                        'live' => true,
                        'default' => '#ffffff',
                        'css' => array(
                            array(
                                'property' => 'background',
                                'selector' => '.c-navbar__hamburger, .c-navbar__search'
                            ),
                        ),
                    ),
                    'this_divider_2937812373' => array(
                        'type' => 'html',
                        'html' => '<span id="section-title-header-colors" class="separator section label large">' . esc_html__('Header', 'theia') . '</span>',
                    ),
                    'header_color' => array(
                        'type' => 'color',
                        'label' => esc_html__('Sticky Header Background Color', 'theia'),
                        'live' => true,
                        'default' => '#ffffff',
                        'css' => array(
                            array(
                                'property' => 'background',
                                'selector' => '.sticky, .c-header--sticky'
                            ),
                        ),
                    ),
                    'this_divider_2937812312' => array(
                        'type' => 'html',
                        'html' => '<span id="section-title-header-colors" class="separator section label large">' . esc_html__('Blog', 'theia') . '</span>',
                    ),
                    'blog_cards_color' => array(
                        'type' => 'color',
                        'label' => esc_html__('Blog Cards Color', 'theia'),
                        'live' => true,
                        'default' => '#f5f5f5',
                        'css' => array(
                            array(
                                'property' => 'background-color',
                                'selector' => '.c-article__flex-item, .c-author, .select2-container--default .select2-selection--single, .select2-container--default .select2-results__option[data-selected=true]'
                            ),
                            array(
                                'property' => 'background',
                                'selector' => 'textarea, .c-author, input[type="text"], input[type="tel"], input[type="number"], input[type="date"], input[type="email"], input[type="password"], input[type="url"], input[type="search"]'
                            ),
                            array(
                                'property' => 'border-color',
                                'selector' => 'textarea, .comment-respond textarea, .comment-respond input[type=text], .comment-respond input[type=email], .comment-respond input[type=url]'
                            ),
                            array(
                                'property' => 'color',
                                'selector' => '.more-projects, .more-projects:hover, .c-category a, .c-category a:hover'
                            ),
                        ),

                    ),
                ),
            ),

            'fonts' => array(
                'title' => '&#x1f4dd; &nbsp;&nbsp;' . esc_html__('Fonts', 'theia'),
                'priority' => 6,
                'options' => array(
                    'this_divider_2931812319' => array(
                        'type' => 'html',
                        'html' => '<span id="section-title-header-colors" class="separator section label large">' . esc_html__('Body Text', 'theia') . '</span>',
                    ),
                    'google_body_font' => array(
                        'type' => 'typography',
                        'label' => esc_html__('Font Family', 'theia'),
                        'desc' => esc_html__('Font for content and widget text.', 'theia'),
                        'recommended' => $recommended_body_fonts,
                        'selector' => 'body',
                        'load_all_weights' => true,
                        'default' => array('Open Sans'),
                    ),
                    'body-font-size' => array(
                        'type' => 'range',
                        'label' => esc_html__('Font Size', 'theia'),
                        'live' => true,
                        'default' => 18,
                        'input_attrs' => array(
                            'min' => 8,
                            'max' => 72,
                            'step' => 1,
                            'data-preview' => true,
                        ),
                        'css' => array(
                            array(
                                'property' => 'font-size',
                                'selector' => 'body',
                                'unit' => 'px',
                            )
                        )
                    ),
                    'body-line-height' => array(
                        'type' => 'range',
                        'label' => esc_html__('Line Height', 'theia'),
                        'live' => true,
                        'default' => '1.8',
                        'input_attrs' => array(
                            'min' => 0,
                            'max' => 3,
                            'step' => 0.1,
                            'data-preview' => true,
                        ),
                        'css' => array(
                            array(
                                'property' => 'line-height',
                                'selector' => 'body',
                            ),
                        ),
                    ),

                    'this_divider_2937812379' => array(
                        'type' => 'html',
                        'html' => '<span id="section-title-header-colors" class="separator section label large">' . esc_html__('Headings', 'theia') . '</span>',
                    ),
                    'google_titles_font' => array(
                        'type' => 'typography',
                        'label' => esc_html__('Font Family', 'theia'),
                        'desc' => esc_html__('Font for titles and headings.', 'theia'),
                        'selector' => '.alpha, h1, h2, h3, h4, h5, h6, blockquote cite, .dropcap, .nocomments, .widget .widget__title, .nav-button, .share-container h4, .article__more, .mfp-title .title',
                        'recommended' => $recommended_headings_fonts,
                        'default' => array('Oswald', '600'),
                        'variants' => array('400', '500', '700'),
                    ),

                    'this_divider_2237812319' => array(
                        'type' => 'html',
                        'html' => '<span id="section-title-header-colors" class="separator section label large">' . esc_html__('Navigation Text', 'theia') . '</span>',
                    ),
                    'google_nav_font' => array(
                        'type' => 'typography',
                        'label' => esc_html__('Font Family', 'theia'),
                        'default' => array('Oswald', '600'),
                        'recommended' => $recommended_body_fonts,
                        'variants' => array('400', '500', '700'),
                        'selector' => '.menu',
                    ),
                    'nav_font-size' => array(
                        'type' => 'range',
                        'label' => esc_html__('Font Size', 'theia'),
                        'live' => true,
                        'default' => 28,
                        'input_attrs' => array(
                            'min' => 8,
                            'max' => 30,
                            'step' => 1,
                            'data-preview' => true,
                        ),
                        'css' => array(
                            array(
                                'property' => 'font-size',
                                'selector' => 'nav ul li a',
                                'unit' => 'px',
                            ),
                        ),
                    ),
                    'nav_letter-spacing' => array(
                        'type' => 'range',
                        'label' => esc_html__('Letter Spacing', 'theia'),
                        'live' => true,
                        'default' => 2,
                        'input_attrs' => array(
                            'min' => -5,
                            'max' => 20,
                            'step' => 1,
                            'data-preview' => true,
                        ),
                        'css' => array(
                            array(
                                'property' => 'letter-spacing',
                                'selector' => 'nav ul li a',
                                'unit' => 'px',
                            ),
                        ),
                    ),
                    'nav_text-transform' => array(
                        'type' => 'select',
                        'label' => esc_html__('Text Transform', 'theia'),
                        'choices' => array(
                            'none' => esc_html__('None', 'theia'),
                            'capitalize' => esc_html__('Capitalize', 'theia'),
                            'uppercase' => esc_html__('Uppercase', 'theia'),
                            'lowercase' => esc_html__('Lowercase', 'theia'),
                        ),
                        'default' => 'uppercase',
                        'css' => array(
                            array(
                                'property' => 'text-transform',
                                'selector' => 'nav ul li a',
                            ),
                        ),
                    ),
                )
            ),

            'layout' => array(
                'title' => '&#x1f4bb; &nbsp;&nbsp;' . esc_html__('Layout', 'theia'),
                'priority' => 7,
                'options' => array(
                    'this_divider_2931812317' => array(
                        'type' => 'html',
                        'html' => '<span id="section-title-header-colors" class="separator section label large">' . esc_html__('Layout', 'theia') . '</span>',
                    ),
                    // Logo Height
                    'header_logo_height' => array(
                        'type' => 'range',
                        'label' => esc_html__('Logo Height', 'theia'),
                        'default' => 24,
                        'live' => true,
                        'input_attrs' => array(
                            'min' => 24,
                            'max' => 240,
                            'step' => 1,
                            'data-preview' => true,
                        ),
                        'css' => array(
                            array(
                                'property' => 'max-height',
                                'selector' => '.logo__img',
                                'unit' => 'px',
                            ),
                            array(
                                'property' => 'font-size',
                                'selector' => '.c-branding__title',
                            ),
                        ),
                    ),

                    // Header Height
                    'header_height' => array(
                        'type' => 'range',
                        'label' => esc_html__('Header Height', 'theia'),
                        'default' => 90,
                        'live' => true,
                        'input_attrs' => array(
                            'min' => 40,
                            'max' => 200,
                            'step' => 1,
                            'data-preview' => true,
                        ),
                        'css' => array(
                            array(
                                'property' => 'height',
                                'selector' => '.c-navbar',
                                'unit' => 'px',
                            ),
                        ),
                    ),

                    'header_sides_spacing' => array(
                        'type' => 'range',
                        'label' => esc_html__('Header Sides Spacing', 'theia'),
                        'default' => 0,
                        'live' => true,
                        'input_attrs' => array(
                            'min' => 0,
                            'max' => 100,
                            'step' => 1,
                        ),
                        'css' => array(
                            array(
                                'property' => 'margin-left',
                                'selector' => '.c-header .u-container-sides-spacing',
                                'unit' => 'px',
                                'media' => ' screen and (min-width: 699px)'
                            ),
                            array(
                                'property' => 'margin-right',
                                'selector' => '.c-header .u-container-sides-spacing',
                                'unit' => 'px',
                                'media' => ' screen and (min-width: 699px) ',
                            ),
                        ),
                    ),

                    // Header Position
                    'header_position' => array(
                        'type' => 'select',
                        'label' => esc_html__('Header Position', 'theia'),
                        'choices' => array(
                            'static' => 'Static',
                            'sticky' => 'Sticky (fixed)',
                        ),
                        'default' => 'sticky',
                        'css' => array(),
                    ),

                ),
            ),

        );

        return $config;
    }
}

add_filter('customify_filter_fields', 'add_customify_theia_options', 11);