<?php
/**
 * Merlin WP configuration file.
 *
 * @package   Merlin WP
 * @version   @@pkg.version
 * @link      https://merlinwp.com/
 * @author    Rich Tabor, from ThemeBeans.com & the team at ProteusThemes.com
 * @copyright Copyright (c) 2018, Merlin WP of Inventionn LLC
 * @license   Licensed GPLv3 for Open Source Use
 */

if ( ! class_exists( 'Merlin' ) ) {
	return;
}

/**
 * Set directory locations, text strings, and settings.
 */
$wizard = new Merlin(

	$config  = array(
		'directory'            => '', // Location / directory where Merlin WP is placed in your theme.
        'demo' =>               'demo/',
		'merlin_url'           => 'onboarding',  // The wp-admin page slug where Merlin WP loads.
		'child_action_btn_url' => 'https://support.acidstudios.ro/support/solutions/articles/42000014060-using-a-child-theme', // URL for the 'child-action-link'.
        'merlin_import_files'         => true, // Import Content
        'dev_mode'             => false, // Enable development mode for testing.
		'license_step'         => false, // EDD license activation step.
		'license_required'     => false, // Require the license activation step.
		'license_help_url'     => 'https://acidstudios.ro/', // URL for the 'license-tooltip'.
		'edd_remote_api_url'   => '', // EDD_Theme_Updater_Admin remote_api_url.
		'edd_item_name'        => '', // EDD_Theme_Updater_Admin item_name.
		'edd_theme_slug'       => '', // EDD_Theme_Updater_Admin item_slug.
	),
	$strings = array(
		'admin-menu'               => esc_html__( 'Theme Setup', 'theia' ),

		/* translators: 1: Title Tag 2: Theme Name 3: Closing Title Tag */
		'title%s%s%s%s'            => esc_html__( '%1$s%2$s Themes &lsaquo; Theme Setup: %3$s%4$s', 'theia' ),
		'return-to-dashboard'      => esc_html__( 'Return to the dashboard', 'theia' ),
		'ignore'                   => esc_html__( 'Disable this wizard', 'theia' ),

		'btn-skip'                 => esc_html__( 'Skip', 'theia' ),
		'btn-next'                 => esc_html__( 'Next', 'theia' ),
		'btn-start'                => esc_html__( 'Start', 'theia' ),
		'btn-no'                   => esc_html__( 'Cancel', 'theia' ),
		'btn-plugins-install'      => esc_html__( 'Install', 'theia' ),
		'btn-child-install'        => esc_html__( 'Install', 'theia' ),
		'btn-content-install'      => esc_html__( 'Install', 'theia' ),
		'btn-import'               => esc_html__( 'Import', 'theia' ),
		'btn-license-activate'     => esc_html__( 'Activate', 'theia' ),
		'btn-license-skip'         => esc_html__( 'Later', 'theia' ),

		/* translators: Theme Name */
		'license-header%s'         => esc_html__( 'Activate %s', 'theia' ),
		/* translators: Theme Name */
		'license-header-success%s' => esc_html__( '%s is Activated', 'theia' ),
		/* translators: Theme Name */
		'license%s'                => esc_html__( 'Enter your license key to enable remote updates and theme support.', 'theia' ),
		'license-label'            => esc_html__( 'License key', 'theia' ),
		'license-success%s'        => esc_html__( 'The theme is already registered, so you can go to the next step!', 'theia' ),
		'license-json-success%s'   => esc_html__( 'Your theme is activated! Remote updates and theme support are enabled.', 'theia' ),
		'license-tooltip'          => esc_html__( 'Need help?', 'theia' ),

		/* translators: Theme Name */
		'welcome-header%s'         => esc_html__( 'Welcome to %s', 'theia' ),
		'welcome-header-success%s' => esc_html__( 'Hi. Welcome back', 'theia' ),
		'welcome%s'                => esc_html__( 'This wizard will set up your theme, install plugins, personalize the theme, and import content. It is optional & should take only a few minutes.', 'theia' ),
		'welcome-success%s'        => esc_html__( 'You may have already run this theme setup wizard. If you would like to proceed anyway, click on the "Start" button below.', 'theia' ),

		'child-header'             => esc_html__( 'Install Child Theme', 'theia' ),
		'child-header-success'     => esc_html__( 'You\'re good to go!', 'theia' ),
		'child'                    => esc_html__( 'Let\'s build & activate a child theme so you may easily make theme changes.', 'theia' ),
		'child-success%s'          => esc_html__( 'Your child theme has already been installed and is now activated, if it wasn\'t already.', 'theia' ),
		'child-action-link'        => esc_html__( 'Learn about child themes', 'theia' ),
		'child-json-success%s'     => esc_html__( 'Awesome. Your child theme has already been installed and is now activated.', 'theia' ),
		'child-json-already%s'     => esc_html__( 'Awesome. Your child theme has been created and is now activated.', 'theia' ),

		'plugins-header'           => esc_html__( 'Install Plugins', 'theia' ),
		'plugins-header-success'   => esc_html__( 'You\'re up to speed!', 'theia' ),
		'plugins'                  => esc_html__( 'Let\'s install some essential WordPress plugins to get your site up to speed.', 'theia' ),
		'plugins-success%s'        => esc_html__( 'The required WordPress plugins are all installed and up to date. Press "Next" to continue the setup wizard.', 'theia' ),
		'plugins-action-link'      => esc_html__( 'Advanced', 'theia' ),

		'import-header'            => esc_html__( 'Import Content', 'theia' ),
		'import'                   => esc_html__( 'Let\'s import content to your website, to help you get familiar with the theme.', 'theia' ),
		'import-action-link'       => esc_html__( 'Advanced', 'theia' ),

		'ready-header'             => esc_html__( 'All done. Have fun!', 'theia' ),

		/* translators: Theme Author */
		'ready%s'                  => esc_html__( 'Your theme has been all set up. Enjoy your new theme by %s.', 'theia' ),
		'ready-action-link'        => esc_html__( 'Extras', 'theia' ),
		'ready-big-button'         => esc_html__( 'View your website', 'theia' ),
		'ready-link-1'             => sprintf( '<a href="%1$s" target="_blank">%2$s</a>', 'https://wordpress.org/support/', esc_html__( 'Explore WordPress', 'theia' ) ),
		'ready-link-2'             => sprintf( '<a href="%1$s" target="_blank">%2$s</a>', 'https://themebeans.com/contact/', esc_html__( 'Get Theme Support', 'theia' ) ),
		'ready-link-3'             => sprintf( '<a href="%1$s">%2$s</a>', admin_url( 'customize.php' ), esc_html__( 'Start Customizing', 'theia' ) ),
	)
);
