<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package THEIA
 */

get_header();
?>

    <div id="primary" class="u-blog-background">
        <main id="main" class="u-content-top-spacing u-content-bottom-spacing">
            <div class="u-container-sides-spacing">
                <div class="o-wrapper u-container-width">
                    <div class="o-layout__page">
                        <?php
                        if (have_posts()) :

                        if (is_home() && !is_front_page()) :
                            ?>
                            <header class="c-page-header">
                                <h1 class="c-page-header__title screen-reader-text"><?php single_post_title(); ?></h1>
                                <?php global $post;
                                $page_for_posts_id = get_option('page_for_posts');
                                if ($page_for_posts_id) :
                                    $post = get_page($page_for_posts_id);
                                    setup_postdata($post);
                                    ?>
                                    <div id="post-<?php the_ID(); ?>">
                                        <header>
                                            <h1 class="c-page-header__title"><?php the_title(); ?></h1>
                                        </header>
                                        <div class="c-page__content">
                                            <?php the_content(); ?>
                                            <?php edit_post_link('Edit', '', '', $page_for_posts_id); ?>
                                        </div>
                                    </div>
                                    <?php
                                    rewind_posts();
                                endif; ?>
                            </header>

                        <?php
                        endif;
                        ?>

                        <div class="o-layout--blog post-listing u-content-top-spacing" data-navigation="<?php echo theia_option('blog_navigation') ?>">

                            <?php

                            while (have_posts()) :
                                the_post();

                                get_template_part('template-parts/content', get_post_type());

                            endwhile;


                            else :

                                get_template_part('template-parts/content', 'none');

                            endif;
                            ?>
                        </div>
                        <?php  (theia_option('blog_navigation') === 'paged') ? theia_numeric_posts_nav() : '' ?>
                    </div>
                </div>
            </div>
        </main>
    </div>

<?php get_footer();
