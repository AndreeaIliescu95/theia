<?php
/**
 * Template Name: Front Page
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package THEIA
 */
get_header();
?>

    <div id="primary" class="u-content-background">
        <main id="main" class="u-content-top-spacing u-content-bottom-spacing">
            <div class="u-container-sides-spacing">
                <div class="o-wrapper u-container-width">
                    <div class="o-layout__page">
                        <?php

                        get_template_part('template-parts/content', 'hero');
                        ?>

                        <div class="c-page__content">
                            <?php
                            while (have_posts()) :
                            the_post(); ?>

                            <?php the_content(); ?>
                        </div>

                    <?php
                    endwhile;
                    wp_reset_query();
                    ?>

                        <?php get_template_part('template-parts/content', 'portfolio'); ?>
                    </div>
                </div>
            </div>
        </main>
    </div>

<?php get_footer();
