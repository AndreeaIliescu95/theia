<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package THEIA
 */

?>

</div>

<footer id="colophon" class="u-footer u-container-sides-spacing u-content-top-spacing u-content-bottom-spacing">
    <div class="o-wrapper u-container-width">
        <div class="c-footer">
            <div class="c-footer__widgets">
                <div class="c-footer__widgets--left">
                    <?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('footer-one')) :

                    endif; ?>
                </div>
                <div class="c-footer__widgets--center">
                    <?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('footer-two')) :

                    endif; ?>
                </div>
                <div class="c-footer__widgets--right">
                    <?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('footer-three')) :

                    endif; ?>
                </div>
            </div>

            <div class="c-footer__copyright">
                <?php echo theia_option('copyright_text', '© ' . date('Y') .' '. get_bloginfo('name')); ?>
            </div>
        </div>
    </div>
</footer>
</div>

<?php wp_footer(); ?>
</body>
</html>
