<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package THEIA
 */

get_header();
?>

    <div id="primary" class="content-area">
        <main id="main" class="site-main" role="main">
            <div class="u-container-sides-spacing u-content-bottom-spacing u-content-top-spacing">
                <div class="o-wrapper u-container-width">
                    <div class="o-layout">
                        <section class="error-404  not-found  o-layout__full">
                            <div class="entry-content">
                                <div class="c-notfound u-content-top-spacing">
                                    <div class="c-notfound__content">
                                        <h1 class="entry-title"><?php esc_html_e('Well hello there!', 'theia'); ?></h1>
                                        <h6><?php esc_html_e('The page you\'re looking for could have been deleted or never have existed', 'theia'); ?></h6>
                                        <h6><?php esc_html_e('But since you are here...', 'theia'); ?></h6>
                                        <h6><?php esc_html_e('take a look at my portfolio', 'theia'); ?></h6>
                                        <a href="<?php echo home_url(); ?>"><button class="c-btn c-btn__notfound">Explore</button></a>
                                    </div>
                                    <div class="c-notfound__error">
                                        <a class="c-notfound__heading glitch">404</a>
                                    </div>
                                </div>
                            </div>

                        </section>
                    </div>
                </div>
            </div>

        </main>
    </div>

<?php
get_footer();
