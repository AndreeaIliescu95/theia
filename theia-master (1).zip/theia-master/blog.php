<?php
/**
 * Template Name: Blog
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package THEIA
 */
get_header(); ?>
<?php query_posts(get_query_var('paged')); ?>
<div id="primary" class="u-blog-background">
    <main id="main" class="u-content-top-spacing u-content-bottom-spacing">
        <div class="u-container-sides-spacing">
            <div class="o-wrapper u-container-width">
                <div class="o-layout--blog u-content-top-spacing">
                    <?php if (have_posts()): ?>

                        <?php while (have_posts()) : the_post();
                            get_template_part('template-parts/content', 'blog');
                            ?>

                        <?php endwhile; ?>
                    <?php endif;
                    wp_reset_query(); ?>
                </div>
            </div>
        </div>
    </main><!-- #main -->
</div><!-- #primary -->

<?php get_footer();
