<?php
/**
 * Template part for displaying single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package THEIA
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class('c-article u-content-bottom-spacing'); ?>>
    <header class="c-page-header">
        <div class="u-content-width">

            <?php if ('post' === get_post_type()) :
                ?>
                <div class="c-page-header__meta c-meta">
                    <div class="c-meta__primary c-meta__primary--left">
                        <?php
                        $categories = get_the_category();
                        if ( ! empty( $categories ) ) {
                            echo '<a class="category" href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '">' . esc_html( $categories[0]->name ) . '</a>';
                        }
                        ?>
                    </div>
                    <div class="c-meta__secondary c-meta__secondary--right">
                        <?php theia_posted_on(); ?>
                    </div>
                </div>
            <?php endif; ?>

            <?php
            if (is_singular()) :
                the_title('<h1 class="c-page-header__title  u-content-bottom-spacing">', '</h1>');
            else :
                the_title('<h2 class="c-page-header__title  u-content-bottom-spacing"><a href="' . esc_url(get_permalink()) . '" rel="bookmark">', '</a></h2>');
            endif;

            ?>
        </div>
        <div class="c-card u-content-bottom-spacing">
            <div class="post-thumbnail">
                <div class="c-card__thumbnail-background">
                    <div class="c-card__frame">
                        <?php if (has_post_thumbnail()) {
                            the_post_thumbnail('theia-single-featured-image');
                        }
                            else { ?>
                        <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/placeholder.jpg"
                             alt="<?php the_title(); ?>"/>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <div class="c-page__content u-content-width u-content-bottom-spacing clearfix">
        <?php
        the_content(sprintf(
            wp_kses(
                __('Continue reading<span class="screen-reader-text"> "%s"</span>', 'theia'),
                array(
                    'span' => array(
                        'class' => array(),
                    ),
                )
            ),
            get_the_title()
        ));

        wp_link_pages(array(
            'before' => '<div class="page-links">' . esc_html__('Pages:', 'theia'),
            'after' => '</div>',
        ));
        ?>

    </div>
    <div class="meta-info u-content-width">
        <div class="c-category">
            <?php $categories_list = get_the_category_list(esc_html__(' ', 'theia'));
            if ($categories_list) {
                printf('<span class="cat-links">' . esc_html__('%1$s', 'theia') . '</span>', $categories_list); // WPCS: XSS OK.
            } ?>
        </div>


        <?php

        if (has_tag()) {


            echo sprintf('<div class="c-tags c-tags--blog"><div class="c-tag__title">%s</div>', esc_html__('Tags:', 'theia'));


            the_tags('<div class="tags">',', ','</div>');

        }

        ?>
    </div>

    <?php theia_social_icons();

    if (theia_option('active_author_box')) {
        theia_author_box();
    }

    $args = array(
        'prev_text' => __('<p class="prev">Prev</p> <p class="navigation-title">%title</p>', 'theia'),
        'next_text' => __('<p class="next">Next</p><p class="navigation-title">%title</p>', 'theia'),
        'screen_reader_text' => __('Posts navigation', 'theia')
    );
    the_post_navigation($args);

    ?>

</article>

<!-- #post-<?php the_ID(); ?> -->
