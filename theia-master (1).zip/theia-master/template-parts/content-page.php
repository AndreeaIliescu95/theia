<?php
/**
 * Template part for displaying page content in page.php
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package THEIA
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class('c-page c-page__content'); ?>
<header class="c-page-header">
    <?php the_title('<h1 class="c-page-header__title u-content-bottom-spacing">', '</h1>'); ?>
</header>

<?php theia_post_thumbnail(); ?>

<div class="c-page__content">
    <?php
    the_content();

    wp_link_pages(array(
        'before' => '<div class="page-links">' . esc_html__('Pages:', 'theia'),
        'after' => '</div>',
    ));
    ?>
</div>

<?php if (get_edit_post_link()) : ?>
    <footer class="c-page__footer">
        <?php
        edit_post_link(
            sprintf(
                wp_kses(
                    __('Edit <span class="screen-reader-text">%s</span>', 'theia'),
                    array(
                        'span' => array(
                            'class' => array(),
                        ),
                    )
                ),
                get_the_title()
            ),
            '<span class="edit-link">',
            '</span>'
        );
        ?>
    </footer>
<?php endif; ?>
</article><!-- #post-<?php the_ID(); ?> -->
