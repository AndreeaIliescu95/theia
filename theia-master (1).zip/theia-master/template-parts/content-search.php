<?php
/**
 * Template part for displaying results in search pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package THEIA
 */

?>

<article class="c-article__flex-item test" id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

    <div class="c-card">

        <div class="c-card__aside c-card__thumbnail-background">

            <div class="c-card__frame"><?php renderOrientation('theia-blog-grid-card', true) ?></div>

        </div>

        <div class="c-card__content">

            <div class="c-card__meta c-meta">
                <div class="c-meta__primary c-meta__primary--left"><?php theia_entry_footer(); ?></div>
                <div class="c-meta__secondary c-meta__secondary--right"><?php theia_posted_on(); ?></div>
            </div>

            <h2 class="c-card__title"><a href="<?php the_permalink() ?>" rel="nofollow"><?php the_title(); ?></a></h2>

            <?php if ('post' === get_post_type()) : ?>

            <?php endif; ?>

            <div class="c-card__excerpt"><?php the_excerpt(); ?></div>

            <div class="c-card__footer">
                <div class="c-card__action">
                    <a class="c-btn c-btn__read" href="<?php the_permalink() ?>"
                       rel="nofollow"><?php esc_html_e('Be Curious', 'theia'); ?></a>
                </div>
            </div>

        </div>

        <a class="c-card__link" href="<?php the_permalink(); ?>"></a>

    </div>
</article>
<!-- #post-<?php the_ID(); ?> -->
