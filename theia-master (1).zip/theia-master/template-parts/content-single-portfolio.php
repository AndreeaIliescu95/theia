<?php
/**
 * Template part for displaying single portfolio content
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package THEIA
 */

?>


<article id="post-<?php the_ID(); ?>" <?php post_class('c-grid'); ?>>

    <?php
    if (has_post_thumbnail()) {
        $background_img = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), 'theia-single-featured-image');
        $background_img = $background_img[0];
    } else {
        $background_img = get_template_directory_uri().'/assets/images/placeholder.jpg';
    }
    ?>
    <div class="post-thumbnail" style="background-image: url('<?php echo $background_img; ?>')">
        <div class="c-hero__slider-overlay"></div>
    </div>
    <header class="c-grid--header u-content-top-spacing">
        <div class="c-page--header__title">
            <h1 class="u-portfolio-title"><?php the_title(); ?></h1>
        </div>
    </header>
    <?php
    $meta = get_post_meta($post->ID, 'portfolio_fields', true);

    if ($meta != '') {
        echo '<div class="c-grid__metas">';
        if($meta['commissioned_by'] != ''){
            echo '<div class="c-grid__metas--field">' . '<span class="field-title">' . __('Collaboration', 'theia') . '</span></br>' . $meta['commissioned_by'] . '</div>';
        }
        if($meta['role'] != ''){
            echo '<div class="c-grid__metas--field">' . '<span class="field-title">' . __('Role', 'theia') . '</span></br>' . $meta['role'] . '</div>';
        }
        if($meta['technic'] != ''){
            echo '<div class="c-grid__metas--field">' . '<span class="field-title">' . __('Technic', 'theia') . '</span></br>' . $meta['technic'] . '</div>';
        }
        if($meta['place'] != ''){
            echo '<div class="c-grid__metas--field">' . '<span class="field-title">' . __('Place', 'theia') . '</span></br>' . $meta['place'] . '</div>';
        }
        if($meta['year'] != ''){
            echo '<div class="c-grid__metas--field">' . '<span class="field-title">' . __('Year', 'theia') . '</span></br>' . $meta['year'] . '</div>';
        }
        if($meta['awards'] != ''){
            echo '<div class="c-grid__metas--field">' . '<span class="field-title">' . __('Awards', 'theia') . '</span></br>' . $meta['awards'] . '</div>';
        }

        echo '</div>';
    }

    ?>

    <div class="c-page__content u-content-width u-content-top-spacing chocolat-parent clearfix">

        <?php
        the_content();

        wp_link_pages(array(
            'before' => '<div class="page-links">' . esc_html__('Pages:', 'theia'),
            'after' => '</div>',
        ));
        ?>

        <div class="c-grid--footer__meta u-content-top-spacing">
            <div class="c-category">
                <?php
                $taxonomy = 'portfolio-categories';
                $post_id = $post->ID;
                $custom_terms = wp_get_post_terms($post_id, $taxonomy);
                foreach ($custom_terms as $custom_term) {
                    wp_reset_query();
                    $args = array('post_type' => 'portfolio',
                        'tax_query' => array(
                            array(
                                'taxonomy' => 'portfolio-categories',
                                'field' => 'slug',
                                'terms' => $custom_term->slug,
                            ),
                        ),
                    );
                    $loop = new WP_Query($args);
                    if ($loop->have_posts()) {
                        $cat_link = get_term_link($custom_term->slug, 'portfolio-categories');
                        echo '<a  href="' . $cat_link . '" >' . $custom_term->name . '</a>';
                    }
                }
                ?>
            </div>

            <?php
            $taxonomy = 'portfolio-tags';
            $post_id = $post->ID;
            $custom_terms = wp_get_post_terms($post_id, $taxonomy);
            foreach ($custom_terms as $custom_term) {
                wp_reset_query();
                $args = array('post_type' => 'portfolio',
                    'tax_query' => array(
                        array(
                            'taxonomy' => 'portfolio-tags',
                            'field' => 'slug',
                            'terms' => $custom_term->slug,
                        ),
                    ),
                );
                $loop = new WP_Query($args);
                if ($loop->have_posts()) {
                    $cat_link = get_term_link($custom_term->slug, 'portfolio-tags');
                    echo '<div class="c-tags">';
                    echo '<a href="' . $cat_link . '"  >#' . $custom_term->name . '</a>';
                    echo '</div>';
                }
            }
            ?>

        </div>
    </div>


    <footer class="c-grid__footer">
        <?php
        theia_social_icons();
        ?>
    </footer>
</article><!-- #post-<?php the_ID(); ?> -->
