<?php

if (taxonomy_exists('portfolio-categories')) { ?>

    <div class="c-grid c-grid--full">
        <?php
        $posts_per_page = theia_option('portfolio_featured_posts_per_page', 1);
        $order = theia_option('portfolio_featured_order', 'desc');
        $orderby = theia_option('portfolio_featured_orderby', 'ID');

        $args = array(
            'post_type' => 'portfolio',
            'meta_query' => array(
                array(
                    'key' => 'portfolio_featured',
                    'value' => '1',
                    'compare' => '='
                )
            ),
            'posts_per_page' => $posts_per_page,
            'order' => $order,
            'orderby' => $orderby
        );

        $loop = new WP_Query($args);

        if ($loop->have_posts()) {
            ?>

            <div class="c-grid__filters">
                <div class="u-filter-label"><?php echo esc_html_e('Filter by:', 'theia'); ?></div>
                <button type="button" class="c-btn__filter c-btn__filter--active" data-filter="*">All</button>
                <?php
                $custom_terms = get_terms('portfolio-categories');
                foreach ($custom_terms as $custom_term) {
                    wp_reset_query();
                    $terms_args = array(
                        'post_type' => 'portfolio',
                        'meta_query' => array(
                            array(
                                'key' => 'portfolio_featured',
                                'value' => '1',
                                'compare' => '='
                            )
                        ),
                        'tax_query' => array(
                            array(
                                'taxonomy' => 'portfolio-categories',
                                'field' => 'slug',
                                'terms' => $custom_term->slug,
                            ),
                        ),
                    );

                    $terms_loop = new WP_Query($terms_args);
                    if ($terms_loop->have_posts()) { ?>
                        <button type="button"
                                class="c-btn__filter"
                                data-filter="<?php echo strtolower(str_replace(' ', '-', $custom_term->name)) ?>">
                            <?php echo $custom_term->name ?>
                        </button>
                        <?php
                    }
                }
                ?>
            </div>

            <div class="c-grid__layout">
                <?php

                while ($loop->have_posts()) : $loop->the_post();
                    $terms_arr = get_the_terms($post->ID, 'portfolio-categories');
                    $category = '';
                    if ($terms_arr) {
                        if (count($terms_arr) > 1) {
                            $category = array();
                            foreach ($terms_arr as $term_arr) {
                                $category[] = $term_arr->slug;
                            }
                            $category = implode('-', $category);
                        } else {
                            $category = $terms_arr[0]->slug;
                        }
                    }

                    ?>
                    <div class="c-grid__item <?php echo $category; ?>">
                        <div class="c-grid__inner">
                            <div class="c-grid__image-container">
                                <a class="c-grid__link" href="<?php the_permalink(); ?>">
                                    <?php if (has_post_thumbnail()) {
                                        the_post_thumbnail('theia-portfolio-grid-card');
                                    } else { ?>
                                        <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/placeholder.jpg"
                                             alt="<?php the_title(); ?>"/>
                                    <?php } ?>
                                </a>
                            </div>
                        </div>
                        <div class="c-grid__item-content">
                            <span class="c-grid__title"><?php the_title(); ?></span>
                        </div>
                    </div>

                <?php
                endwhile;
                ?>
            </div>
            <a href="<?php echo get_post_type_archive_link('portfolio'); ?>"
               class="button more-projects"><?php _e('View More', 'theia'); ?></a>
        <?php } ?>
    </div>
<?php } ?>