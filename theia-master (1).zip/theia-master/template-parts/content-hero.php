<?php
/**
 * Template part for displaying hero area
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package THEIA
 */
?>

<div class="c-hero c-hero--full">

    <?php
    $args = array(
        'post_type' => 'portfolio',
        'meta_query' => array(
            array(
                'key' => 'hero_area_featured',
                'value' => '1',
                'compare' => '='
            )
        ),
        'posts_per_page' => 5,
        'order' => 'desc'
    );

    $loop = new WP_Query($args);

    if ($loop->have_posts()) {

        $_autoplay = theia_option('active_autoplay', false);
        $autoplay = theia_stringed_boolean($_autoplay);

        $autoplay_speed = theia_option('autoplay_speed', '8000');

        $displace_scale = theia_option('transition_speed', 'medium');

        $distorsion_scale = theia_option('distorsion_scale', '2048x2048');
        $distorsion_effect = theia_option('distorsion_effect', 'clouds');
        $displacement_image = get_template_directory_uri() . '/assets/images/dmaps/' . $distorsion_scale . '/' . $distorsion_effect . '.jpg';

        $_active_animation = theia_option('active_animation', true);
        $active_animation = theia_stringed_boolean($_active_animation);

        $animation_speed = theia_option('animation_speed', 'medium');

        $_active_title = theia_option('active_title', true);
        $active_title = theia_stringed_boolean($_active_title);

        $_active_scroll_down = theia_option('active_scroll_down', true);
        $active_scroll_down = theia_stringed_boolean($_active_scroll_down);

        $_active_bullets = theia_option('active_bullets', true);
        $active_bullets = theia_stringed_boolean($_active_bullets);

        $_active_view_project = theia_option('active_view_project', true);
        $active_view_project = theia_stringed_boolean($_active_view_project);
        $view_project_text = theia_option('view_project_text', 'View Project');

        $_active_keyboard_nav = theia_option('active_keyboard_nav', true);
        $active_keyboard_nav = theia_stringed_boolean($_active_keyboard_nav);

        $default_img = get_template_directory_uri() . '/assets/images/placeholder.jpg';

        $data_params = array(
            'autoplay' => $autoplay,
            'autoplaySpeed' => $autoplay_speed,
            'displaceScale' => $displace_scale,
            'displacementImage' => $displacement_image,
            'activeAnimation' => $active_animation,
            'animationSpeed' => $animation_speed,
            'activeTitle' => $active_title,
            'activeScrollDown' => $active_scroll_down,
            'activeBullets' => $active_bullets,
            'activeViewProject' => $active_view_project,
            'viewProjectText' => $view_project_text,
            'activeKeyboardNav' => $active_keyboard_nav
        );

        $data_params_json = json_encode($data_params);
        ?>

        <div class="c-hero__slider"
             data-params="<?php echo htmlspecialchars($data_params_json, ENT_QUOTES, 'UTF-8'); ?>">

            <div class="c-hero__slider-overlay"></div>

            <div class="c-hero__wrapper">
                <?php
                while ($loop->have_posts()) {
                    $loop->the_post();
                    ?>

                    <div class="c-hero__slide slide-item"
                         data-link="<?php the_permalink() ?>"
                         data-title="<?php the_title() ?>">
                        <img class="slide-item__image"
                             src="<?php echo has_post_thumbnail() ? get_the_post_thumbnail_url() : $default_img ?>">
                    </div>
                <?php } ?>
            </div>

            <button class="scene-nav scene-nav--prev" data-nav="previous">
                <i class="medium material-icons">chevron_left</i>
            </button>
            <button class="scene-nav scene-nav--next" data-nav="next">
                <i class="medium material-icons">chevron_right</i>
            </button>

        </div>

    <?php } else {
        if(is_user_logged_in()){
            ?>
            <a href="<?php echo get_dashboard_url().'edit.php?post_type=portfolio' ?>">
                <?php
                echo __( 'Oups, there are no projects. Click here to add one.', 'theia' );
                ?>
            </a>
            <?php
        } else {
            echo '<p>'.__('Oups, there are no projects.', 'theia').'</p>';
        }
    } ?>
</div>