<div class="c-grid__item">
    <div class="c-grid__inner">
        <div class="c-grid__image-container">
            <a class="c-grid__link" href="<?php the_permalink(); ?>">
                <?php if ( has_post_thumbnail() ) {
                    the_post_thumbnail('theia-portfolio-grid-card');
                } else { ?>
                    <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/placeholder.jpg" alt="<?php the_title(); ?>" />
                <?php } ?>
            </a>
        </div>
    </div>
    <div class="c-grid__item-content">
        <span class="c-grid__title"><?php the_title(); ?></span>
    </div>
</div>