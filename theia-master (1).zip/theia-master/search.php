<?php
/**
 * The template for displaying search results pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#search-result
 *
 * @package THEIA
 */

get_header();
?>

    <section id="primary" class="u-blog-background">
        <main id="main" class="u-content-top-spacing u-content-bottom-spacing">
            <div class="u-container-sides-spacing">
                <div class="o-wrapper u-container-width">
                    <div class="o-layout--page">
                        <?php if (have_posts()) : ?>

                        <header class="c-page-header">
                            <h1 class="c-page-header__title">
                                <?php
                                printf(esc_html__('Search Results for: %s', 'theia'), '<span>' . get_search_query() . '</span>');
                                ?>
                            </h1>
                        </header><!-- .page-header -->
                        <div class="o-layout--blog u-content-top-spacing">
                            <?php
                            /* Start the Loop */
                            while (have_posts()) :
                                the_post();

                                get_template_part('template-parts/content', 'search');

                            endwhile;

                            theia_numeric_posts_nav();

                            else :

                                get_template_part('template-parts/content', 'none');

                            endif;
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </section>

<?php
get_footer();
