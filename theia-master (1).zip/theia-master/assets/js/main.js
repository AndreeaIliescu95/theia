(function ($, window, document, undefined) {

    "use strict";
    var $html = $('html'),
        $body = $('body'),
        $window = $(window),
        $document = $(document);

    var ua = navigator.userAgent,
        isiPhone = false,
        isiPad = false,
        isiPod = false,
        isAndroidPhone = false,
        android = false,
        iOS = false,
        isIE = false,
        ieMobile = false,
        isSafari = false,
        isMac = false;

    //Util
    var Util = {
        isHome: !!$body.hasClass('home'),

        isLogged: !!$body.hasClass('logged-in'),

        getIOSVersion: function () {
            ua = ua || navigator.userAgent;
            return parseFloat(
                ('' + (/CPU.*OS ([0-9_]{1,5})|(CPU like).*AppleWebKit.*Mobile/i.exec(ua) || [0, ''])[1])
                    .replace('undefined', '3_2').replace('_', '.').replace('_', '')
            ) || false;
        },

        getAndroidVersion: function (ua) {
            var matches;
            ua = ua || navigator.userAgent;
            matches = ua.match(/[A|a]ndroid\s([0-9\.]*)/);
            return matches ? matches[1] : false;
        },

        platformDetect: function () {
            var navUA = navigator.userAgent,
                navPlat = navigator.platform.toLowerCase();

            isiPhone = /iphone|ipod/.test(navUA);
            isiPad = navUA.match(/iPad/i) != null;
            isiPod = navPlat.indexOf("ipod");
            isAndroidPhone = navPlat.indexOf("android");
            isSafari = navUA.indexOf('Safari') != -1;
            isIE = typeof (is_ie) !== "undefined" || (!(window.ActiveXObject) && "ActiveXObject" in window);
            ieMobile = ua.match(/Windows Phone/i) ? true : false;
            iOS = Util.getIOSVersion();
            android = Util.getAndroidVersion();
            isMac = navigator.platform.toUpperCase().indexOf('MAC') >= 0;

            if (isIE) {
                $html.addClass('is--ie');
            }

            if (ieMobile) {
                $html.addClass('is--ie-mobile');
            }
        },

        loaderEffect: function () {
            var start = 0.4;
            $('.c-loader span').each(function () {
                start = start += 0.1;
                $(this).css('animation-delay', start + 's');
            });
        },

        triggerSocialButton: function () {
            $('.c-social__text').on('click', function () {
                $('.c-social__text').addClass('hide');
                $('.c-social__blocks').addClass('show');
            });
        },

        removeEmptyPTags: function () {
            if ($window.width() < 960) {
                $('.gridable--col p').each(function (i, v) {
                    if ($(this).html() === '&nbsp;') {
                        $(this).remove();
                    }
                })
            }
        },

        hideWoocommerceIcon: function () {
            if (!$body.hasClass('woocommerce-page')) {
                $('.c-navbar__cart-icon').hide();
            }
        },

        _debounce: function (func, wait, immediate) {
            var timeout;
            return function () {
                var context = this, args = arguments;
                clearTimeout(timeout);
                timeout = setTimeout(function () {
                    timeout = null;
                    if (!immediate) func.apply(context, args);
                }, wait);
                if (immediate && !timeout) func.apply(context, args);
            };
        }
    };

    //Hero Area
    var HeroArea = function () {
        var _this = this;

        this.active = false;

        this.$container = $body.find('.c-hero');

        this.sliderEl = this.$container.find('.c-hero__slider');

        this.getSpriteImagesElements = document.querySelectorAll('.slide-item__image');

        this.getSpriteImagesArray = function () {
            var spriteImages = this.getSpriteImagesElements;
            var spriteImagesSrc = [];
            var texts = [];

            for (var i = 0; i < spriteImages.length; i++) {

                var img = spriteImages[i];

                // Set the texts you want to display to each slide
                // in a sibling element of your image and edit accordingly
                if (img.nextElementSibling) {
                    texts.push(img.nextElementSibling.innerHTML);
                } else {
                    texts.push('');
                }

                spriteImagesSrc.push(img.getAttribute('src'));
            }
            return spriteImagesSrc;
        };

        this.getViewProject = function (index) {
            var active = this.sliderEl.data('params').activeViewProject;

            if (active === 'true') {
                var hero = $('.c-hero__wrapper .slide-item').eq(index).data('link'),
                    btn = $('.c-hero .c-btn__hero');

                btn.attr('href', hero);

                btn.fadeOut(1500);
                setTimeout(function () {
                    btn.fadeIn(1500);
                }, 1500);
            }

        };

        this.getTitle = function (index) {
            var active = this.sliderEl.data('params').activeTitle;

            if (active === 'true') {

                var title = $('.c-hero__wrapper .slide-item').eq(index).data('title'),
                    titleContainer = $('.c-hero__title');

                titleContainer.fadeOut(1500);
                setTimeout(function () {
                    titleContainer.text(title).fadeIn(1500);
                }, 1500);
            }
        };

        this.getTotalItems = function () {
            var total = 0;
            $('.c-hero .c-hero__wrapper .slide-item').each(function (i, v) {
                total++;
            });
            return total;
        };

        this.setBullets = function () {
            if ($('.c-hero .c-hero__wrapper .slide-item').length > 1) {
                $('.c-hero').append('<ul class="c-hero__bullets"></ul>');
                $('.c-hero .c-hero__wrapper .slide-item').each(function (i, v) {
                    $('.c-hero__bullets').append('<li><span></span></li>');
                });

                $('.c-hero__bullets li:first-child span').addClass('is-active');
            }
        };

        this.getBullet = function (index) {
            $('.c-hero__bullets li span').removeClass('is-active');
            $('.c-hero__bullets li').eq(index).find('span').addClass('is-active');
        };

        this.setScrollDown = function () {
            $('.c-hero').append('<div class="c-hero__scroll-down"></div>');
            $('.c-hero__scroll-down').on('click', function (e) {
                e.preventDefault();
                $('html, body').animate({scrollTop: $('#masthead').offset().top}, 500, 'linear');
            });
        };

        this.keyboardNav = function () {
            $body.keydown(function (e) {
                if (e.keyCode === 37) { // left
                    $('.scene-nav--prev').click();
                }
                else if (e.keyCode === 39) { // right
                    $('.scene-nav--next').click();
                }
            });
        };

        this.autoplay = function () {
            function auto() {
                var animationTimeout = 3000,
                    autoplaySpeed = _this.sliderEl.data('params').autoplaySpeed,
                    timeout = Number(animationTimeout) + Number(autoplaySpeed);

                $('.scene-nav--next').click();
                setTimeout(auto, timeout);
            }

            auto();
        };

        this.options =
            {
                sprites: this.getSpriteImagesArray(),
                displacementImage: '',
                displaceScale: [200, 70],
                autoPlay: true,
                autoPlaySpeed: [10, 3],
                centerSprites: true
            }
    };

    HeroArea.prototype.load = function () {
        var _this = this;

        if ($body.hasClass('home') && (this.getTotalItems() > 0)) {
            window.CanvasSlideshow = function (options) {

                //  SCOPE
                /// ---------------------------
                var that = this;


                //  OPTIONS
                /// ---------------------------
                options = options || {};
                options.stageWidth = options.hasOwnProperty('stageWidth') ? options.stageWidth : 1920;
                options.stageHeight = options.hasOwnProperty('stageHeight') ? options.stageHeight : 1080;
                options.pixiSprites = options.hasOwnProperty('sprites') ? options.sprites : [];
                options.texts = options.hasOwnProperty('texts') ? options.texts : [];
                options.autoPlay = options.hasOwnProperty('autoPlay') ? options.autoPlay : true;
                options.autoPlaySpeed = options.hasOwnProperty('autoPlaySpeed') ? options.autoPlaySpeed : [10, 3];
                options.fullScreen = options.hasOwnProperty('fullScreen') ? options.fullScreen : true;
                options.displaceScale = options.hasOwnProperty('displaceScale') ? options.displaceScale : [200, 70];
                options.displacementImage = options.hasOwnProperty('displacementImage') ? options.displacementImage : '';
                options.navElement = options.hasOwnProperty('navElement') ? options.navElement : document.querySelectorAll('.scene-nav');
                options.displaceAutoFit = options.hasOwnProperty('displaceAutoFit') ? options.displaceAutoFit : false;
                options.wacky = options.hasOwnProperty('wacky') ? options.wacky : false;
                options.interactive = options.hasOwnProperty('interactive') ? options.interactive : false;
                options.displaceScaleTo = (options.autoPlay === false) ? [0, 0] : [20, 20];
                options.textColor = options.hasOwnProperty('textColor') ? options.textColor : '#fff';
                options.displacementCenter = options.hasOwnProperty('displacementCenter') ? options.displacementCenter : false;
                options.dispatchPointerOver = options.hasOwnProperty('dispatchPointerOver') ? options.dispatchPointerOver : false;


                //  PIXI VARIABLES
                /// ---------------------------
                var renderer = new PIXI.autoDetectRenderer(options.stageWidth, options.stageHeight, {transparent: true});
                var stage = new PIXI.Container();
                var slidesContainer = new PIXI.Container();
                var displacementSprite = new PIXI.Sprite.fromImage(options.displacementImage);
                var displacementFilter = new PIXI.filters.DisplacementFilter(displacementSprite);


                //  TEXTS
                /// ---------------------------
                var style = new PIXI.TextStyle({
                    fill: options.textColor,
                    wordWrap: true,
                    wordWrapWidth: 400,
                    letterSpacing: 20,
                    fontSize: 14
                });


                //  SLIDES ARRAY INDEX
                /// ---------------------------
                this.currentIndex = 0;


                /// ---------------------------
                //  INITIALISE PIXI
                /// ---------------------------
                this.initPixi = function () {

                    // Add canvas to the HTML
                    var canvasContainer = document.createElement('div');
                    canvasContainer.className = 'canvas-wrap';

                    canvasContainer.appendChild(renderer.view);
                    document.body.appendChild(canvasContainer);

                    // Add child container to the main container
                    stage.addChild(slidesContainer);


                    // Enable Interactions
                    stage.interactive = true;


                    // Fit renderer to the screen
                    if (options.fullScreen === true) {
                        renderer.view.style.objectFit = 'cover';
                        renderer.view.style.width = '100%';
                        renderer.view.style.height = '100%';
                        renderer.view.style.top = '50%';
                        renderer.view.style.left = '50%';
                        renderer.view.style.webkitTransform = 'translate( -50%, -50% ) scale(1.2)';
                        renderer.view.style.transform = 'translate( -50%, -50% ) scale(1.2)';
                    } else {
                        renderer.view.style.maxWidth = '100%';
                        renderer.view.style.top = '50%';
                        renderer.view.style.left = '50%';
                        renderer.view.style.webkitTransform = 'translate( -50%, -50% )';
                        renderer.view.style.transform = 'translate( -50%, -50% )';
                    }


                    displacementSprite.texture.baseTexture.wrapMode = PIXI.WRAP_MODES.REPEAT;


                    // Set the filter to stage and set some default values for the animation
                    stage.filters = [displacementFilter];

                    if (options.autoPlay === false) {
                        displacementFilter.scale.x = 0;
                        displacementFilter.scale.y = 0;
                    }

                    if (options.wacky === true) {

                        displacementSprite.anchor.set(0.5);
                        displacementSprite.x = renderer.width / 2;
                        displacementSprite.y = renderer.height / 2;
                    }

                    displacementSprite.scale.x = 2;
                    displacementSprite.scale.y = 2;

                    // PIXI tries to fit the filter bounding box to the renderer
                    // so we optionally bypass
                    displacementFilter.autoFit = options.displaceAutoFit;

                    stage.addChild(displacementSprite);

                };


                /// ---------------------------
                //  LOAD SLIDES TO CANVAS
                /// ---------------------------
                this.loadPixiSprites = function (sprites) {


                    var rSprites = options.sprites;
                    var rTexts = options.texts;

                    for (var i = 0; i < rSprites.length; i++) {

                        var texture = new PIXI.Texture.fromImage(sprites[i]);
                        var image = new PIXI.Sprite(texture);

                        if (rTexts) {
                            var richText = new PIXI.Text(rTexts[i], style);
                            image.addChild(richText);

                            richText.anchor.set(0.5);
                            richText.x = image.width / 2;
                            richText.y = image.height / 2;
                        }


                        if (options.centerSprites === true) {
                            image.anchor.set(0.5);
                            image.x = renderer.width / 2;
                            image.y = renderer.height / 2;
                        }
                        //image.transform.scale.x = 1.3;
                        //image.transform.scale.y = 1.3; 


                        if (i !== 0) {
                            TweenLite.set(image, {alpha: 0});
                        }

                        slidesContainer.addChild(image);

                    }

                };


                /// ---------------------------
                //  DEFAULT RENDER/ANIMATION
                /// ---------------------------
                if (options.autoPlay === true) {

                    var ticker = new PIXI.ticker.Ticker();

                    ticker.autoStart = options.autoPlay;


                    ticker.add(function (delta) {

                        displacementSprite.x += options.autoPlaySpeed[0] * delta;
                        displacementSprite.y += options.autoPlaySpeed[1];

                        displacementSprite.x += 0.12 * delta;
                        displacementSprite.y += 1.24 * delta;

                        renderer.render(stage);

                    });

                } else {

                    var render = new PIXI.ticker.Ticker();

                    render.autoStart = true;

                    render.add(function (delta) {
                        renderer.render(stage);
                    });

                }


                /// ---------------------------
                //  TRANSITION BETWEEN SLIDES
                /// ---------------------------

                var transitionAnimation = new PIXI.ticker.Ticker();
                transitionAnimation.autoStart = false;

                transitionAnimation.add(function (delta) {
                    displacementSprite.x += options.autoPlaySpeed[0] * delta;
                    displacementSprite.y += options.autoPlaySpeed[1];

                    displacementSprite.x += 2.12 * delta;
                    displacementSprite.y += 22.24 * delta;

                });


                var isPlaying = false;
                var slideImages = slidesContainer.children;
                this.moveSlider = function (newIndex) {
                    isPlaying = true;
                    transitionAnimation.start();
                    var baseTimeline = new TimelineLite({
                        onComplete: function () {
                            that.currentIndex = newIndex;
                            isPlaying = false;
                            transitionAnimation.stop();
                            if (options.wacky === true) {
                                displacementSprite.scale.set(1);
                            }
                        }, onUpdate: function () {

                            if (options.wacky === true) {
                                displacementSprite.rotation += baseTimeline.progress() * 0.02;
                                displacementSprite.scale.set(baseTimeline.progress() * 3);
                            }

                        }
                    });

                    baseTimeline.clear();

                    if (baseTimeline.isActive()) {
                        return;
                    }

                    baseTimeline
                        .to(displacementFilter.scale, 1, {x: options.displaceScale[0], y: options.displaceScale[1]})
                        .to(slideImages[that.currentIndex], 0.5, {alpha: 0})
                        .to(slideImages[newIndex], 0.5, {alpha: 1})
                        .to(displacementFilter.scale, 1, {
                            x: options.displaceScaleTo[0],
                            y: options.displaceScaleTo[1]
                        });

                };


                var index = 0;

                /// ---------------------------
                //  CLICK HANDLERS
                /// ---------------------------
                var nav = options.navElement;

                for (var i = 0; i < nav.length; i++) {

                    var navItem = nav[i];

                    navItem.onclick = function (event) {

                        // Make sure the previous transition has ended
                        if (isPlaying) {
                            return false;
                        }

                        if (this.getAttribute('data-nav') === 'next') {

                            if (that.currentIndex >= 0 && that.currentIndex < slideImages.length - 1) {
                                index = that.currentIndex + 1;
                                that.moveSlider(index);
                                _this.getTitle(index);
                                _this.getViewProject(index);
                                _this.getBullet(index);
                            } else {
                                that.moveSlider(0);
                                _this.getTitle(0);
                                _this.getViewProject(0);
                                _this.getBullet(0);
                            }

                        } else {

                            if (that.currentIndex > 0 && that.currentIndex < slideImages.length) {
                                index = that.currentIndex - 1;
                                that.moveSlider(index);
                                _this.getTitle(index);
                                _this.getViewProject(index);
                                _this.getBullet(index);
                            } else {
                                that.moveSlider(_this.getSpriteImagesElements.length - 1);
                                _this.getTitle(_this.getSpriteImagesElements.length - 1);
                                _this.getViewProject(_this.getSpriteImagesElements.length - 1);
                                _this.getBullet(_this.getSpriteImagesElements.length - 1);
                            }

                        }

                        return false;

                    }

                }


                /// ---------------------------
                //  INIT FUNCTIONS
                /// ---------------------------
                this.init = function () {


                    that.initPixi();
                    that.loadPixiSprites(options.pixiSprites);

                    /*
                    if ( options.fullScreen === true ) {
                      window.addEventListener("resize", function( event ){
                        scaleToWindow( renderer.view );
                      });
                      scaleToWindow( renderer.view );
                    }
                    */


                };


                /// ---------------------------
                //  INTERACTIONS
                /// ---------------------------
                function rotateSpite() {
                    displacementSprite.rotation += 0.001;
                    rafID = requestAnimationFrame(rotateSpite);
                }

                if (options.interactive === true) {

                    var rafID, mouseX, mouseY;

                    // Enable interactions on our slider
                    slidesContainer.interactive = true;
                    slidesContainer.buttonMode = true;

                    // HOVER
                    if (options.interactionEvent === 'hover' || options.interactionEvent === 'both') {

                        slidesContainer.pointerover = function (mouseData) {
                            mouseX = mouseData.data.global.x;
                            mouseY = mouseData.data.global.y;
                            TweenLite.to(displacementFilter.scale, 1, {
                                x: "+=" + Math.sin(mouseX) * 100 + "",
                                y: "+=" + Math.cos(mouseY) * 100 + ""
                            });
                            rotateSpite();
                        };

                        slidesContainer.pointerout = function (mouseData) {
                            TweenLite.to(displacementFilter.scale, 1, {x: 0, y: 0});
                            cancelAnimationFrame(rafID);
                        };

                    }

                    // CLICK
                    if (options.interactionEvent === 'click' || options.interactionEvent === 'both') {

                        slidesContainer.pointerup = function (mouseData) {
                            if (options.dispatchPointerOver === true) {
                                TweenLite.to(displacementFilter.scale, 1, {
                                    x: 0, y: 0, onComplete: function () {
                                        TweenLite.to(displacementFilter.scale, 1, {x: 20, y: 20});
                                    }
                                });
                            } else {
                                TweenLite.to(displacementFilter.scale, 1, {x: 0, y: 0});
                                cancelAnimationFrame(rafID);
                            }

                        };

                        slidesContainer.pointerdown = function (mouseData) {
                            mouseX = mouseData.data.global.x;
                            mouseY = mouseData.data.global.y;
                            TweenLite.to(displacementFilter.scale, 1, {
                                x: "+=" + Math.sin(mouseX) * 1200 + "",
                                y: "+=" + Math.cos(mouseY) * 200 + ""
                            });
                        };

                        slidesContainer.pointerout = function (mouseData) {
                            if (options.dispatchPointerOver === true) {
                                TweenLite.to(displacementFilter.scale, 1, {
                                    x: 0, y: 0, onComplete: function () {
                                        TweenLite.to(displacementFilter.scale, 1, {x: 20, y: 20});
                                    }
                                });
                            } else {
                                TweenLite.to(displacementFilter.scale, 1, {x: 0, y: 0});
                                cancelAnimationFrame(rafID);
                            }

                        };

                    }

                }


                /// ---------------------------
                //  CENTER DISPLACEMENT
                /// ---------------------------
                if (options.displacementCenter === true) {
                    displacementSprite.anchor.set(0.5);
                    displacementSprite.x = renderer.view.width / 2;
                    displacementSprite.y = renderer.view.height / 2;
                }


                /// ---------------------------
                //  START
                /// ---------------------------
                this.init();


                /// ---------------------------
                //  HELPER FUNCTIONS
                /// ---------------------------
                function scaleToWindow(canvas, backgroundColor) {
                    var scaleX, scaleY, scale, center;

                    //1. Scale the canvas to the correct size
                    //Figure out the scale amount on each axis
                    scaleX = window.innerWidth / canvas.offsetWidth;
                    scaleY = window.innerHeight / canvas.offsetHeight;

                    //Scale the canvas based on whichever value is less: `scaleX` or `scaleY`
                    scale = Math.min(scaleX, scaleY);
                    canvas.style.transformOrigin = "0 0";
                    canvas.style.transform = "scale(" + scale + ")";

                    //2. Center the canvas.
                    //Decide whether to center the canvas vertically or horizontally.
                    //Wide canvases should be centered vertically, and
                    //square or tall canvases should be centered horizontally
                    if (canvas.offsetWidth > canvas.offsetHeight) {
                        if (canvas.offsetWidth * scale < window.innerWidth) {
                            center = "horizontally";
                        } else {
                            center = "vertically";
                        }
                    } else {
                        if (canvas.offsetHeight * scale < window.innerHeight) {
                            center = "vertically";
                        } else {
                            center = "horizontally";
                        }
                    }

                    //Center horizontally (for square or tall canvases)
                    var margin;
                    if (center === "horizontally") {
                        margin = (window.innerWidth - canvas.offsetWidth * scale) / 2;
                        canvas.style.marginTop = 0 + "px";
                        canvas.style.marginBottom = 0 + "px";
                        canvas.style.marginLeft = margin + "px";
                        canvas.style.marginRight = margin + "px";
                    }

                    //Center vertically (for wide canvases)
                    if (center === "vertically") {
                        margin = (window.innerHeight - canvas.offsetHeight * scale) / 2;
                        canvas.style.marginTop = margin + "px";
                        canvas.style.marginBottom = margin + "px";
                        canvas.style.marginLeft = 0 + "px";
                        canvas.style.marginRight = 0 + "px";
                    }

                    //3. Remove any padding from the canvas  and body and set the canvas
                    //display style to "block"
                    canvas.style.paddingLeft = 0 + "px";
                    canvas.style.paddingRight = 0 + "px";
                    canvas.style.paddingTop = 0 + "px";
                    canvas.style.paddingBottom = 0 + "px";
                    canvas.style.display = "block";

                    //4. Set the color of the HTML body background
                    document.body.style.backgroundColor = backgroundColor;

                    //Fix some quirkiness in scaling for Safari
                    var ua = navigator.userAgent.toLowerCase();
                    if (ua.indexOf("safari") != -1) {
                        if (ua.indexOf("chrome") > -1) {
                            // Chrome
                        } else {
                            // Safari
                            //canvas.style.maxHeight = "100%";
                            //canvas.style.minHeight = "100%";
                        }
                    }

                    //5. Return the `scale` value. This is important, because you'll nee this value
                    //for correct hit testing between the pointer and sprites
                    return scale;
                } // http://bit.ly/2y1Yk2k


            };

            this.active = true;
        }
    };

    HeroArea.prototype.init = function () {
        var _this = this;
        var $container = this.$container;

        if (this.active) {

            var slider = $container.find('.c-hero__slider'),
                dataParams = slider.data('params');

            switch (dataParams.animationSpeed) {
                case 'slow':
                    dataParams.animationSpeed = [1, 1];
                    break;
                case 'medium':
                    dataParams.animationSpeed = [3, 3];
                    break;
                case 'fast':
                    dataParams.animationSpeed = [7, 7];
                    break;
                default:
                    dataParams.animationSpeed = [1, 1];
                    break;
            }

            switch (dataParams.displaceScale) {
                case 'minor':
                    dataParams.displaceScale = [300, 100];
                    break;
                case 'medium':
                    dataParams.displaceScale = [600, 200];
                    break;
                case 'major':
                    dataParams.displaceScale = [1200, 400];
                    break;
                default:
                    dataParams.displaceScale = [300, 100];
                    break;
            }

            $.extend(_this.options, {
                autoPlay: dataParams.activeAnimation === 'true',
                autoPlaySpeed: dataParams.animationSpeed,
                displacementImage: dataParams.displacementImage,
                displaceScale: dataParams.displaceScale
            });

            new CanvasSlideshow(_this.options);

            $body.find('.canvas-wrap').detach().prependTo($body);

            if (_this.getTotalItems() === 1) {
                $('.c-hero .scene-nav').hide();
            }

            if (Util.isLogged) {
                if (Util.isHome) {
                    $('.c-hero__slider-overlay').css('margin-top', '32px');
                }
            }

            if (dataParams.autoplay === 'true') {
                var animationTimeout = 3000,
                    autoplaySpeed = _this.sliderEl.data('params').autoplaySpeed,
                    timeout = Number(animationTimeout) + Number(autoplaySpeed);

                setTimeout(function () {
                    _this.autoplay();
                }, timeout);
            }

            if (dataParams.activeTitle === 'true') {
                $('.c-hero__slider').append('<h1 class="c-hero__title"></h1>');
                var title = $('.c-hero__wrapper .slide-item').eq(0).data('title');
                $('.c-hero__title').text(title);
            }

            if (dataParams.activeViewProject === 'true') {
                $('.c-hero__slider').append('<a href="#" class="c-btn c-btn__hero">' + dataParams.viewProjectText + '</a>');
                var firstHero = $container.find('.c-hero__wrapper .slide-item').eq(0).data('link');
                $container.find('.c-btn__hero').attr('href', firstHero);
            }

            if (dataParams.activeScrollDown === 'true') {
                _this.setScrollDown();
            }

            if (dataParams.activeBullets === 'true') {
                _this.setBullets();
            }

            if (dataParams.activeKeyboardNav === 'true') {
                _this.keyboardNav();
            }
        }
    };

    //Portfolio
    var Portfolio = function () {
        this.$container = $body.find('.c-grid.c-grid--full');

        this.titlePositioning = function () {
            $('.c-grid__item').each(function () {
                var title = $(this).find('.c-grid__item-content'),
                    offsetTitle = title.offset().top,
                    image = $(this).find('.c-grid__link img'),
                    offsetImage = image.offset().top,
                    imageHeight = image.height(),
                    imageWidth = image.width(),

                    marginTop = offsetImage - (offsetTitle - imageHeight) + 15,
                    paddingLeft = ($(this).width() - imageWidth) / 2;

                title.css({
                    "margin-top": marginTop,
                    "padding-left": paddingLeft
                });
            });
        };

        this.destroyTitlePositioning = function () {
            $('.c-grid__item-content').css({
                "margin-top": "0",
                "padding-left": "0"
            });
        }

        this.filter = function () {
            var $filters = this.$container.find('.c-grid__filters');
            var $grid = this.$container.find('.c-grid__layout');
            if ($filters.length) {
                $filters.find('.c-btn__filter').on('click', function () {
                    $filters.find('.c-btn__filter').removeClass('c-btn__filter--active');
                    $(this).addClass('c-btn__filter--active');
                    var filter = $(this).data('filter'),
                        portfolioItem = $grid.find('.c-grid__item');
                    portfolioItem.hide();

                    if (filter === '*') {
                        portfolioItem.fadeIn(800);
                    } else {

                        portfolioItem.each(function (i, v) {
                            var classes = $(this).attr('class').split(' ');
                            for (var i = 0; i < classes.length; i++) {
                                if (classes[i].indexOf(filter) !== -1) {
                                    $(this).fadeIn(800);
                                }
                            }
                        });
                    }

                });
            }
        };

        this.parallax = function () {
            if ($window.width() >= 960) {
                if ($('.c-grid__layout').length && !$('.c-grid').parent().hasClass('c-product__related')) {

                    var elObj = {};

                    $('.c-grid__item').each(function (i, v) {
                        if (i % 3 === 0) {
                            $(this).data('pos', 0);
                        } else if ((i + 2) % 3 === 0) {
                            $(this).data('pos', 1);
                        } else if ((i + 1) % 3 === 0) {
                            $(this).data('pos', 2);
                        }

                        var elPos = $(this).data('pos');

                        elObj[elPos] = 0;
                    });

                    var startSpeed = 0.05;
                    $.each(elObj, function (key, value) {
                        if (key === '0') {
                            elObj[key] = startSpeed += 0.03;
                        } else if (key === '1') {
                            elObj[key] = startSpeed -= 0.07;
                        } else if (key === '2') {
                            elObj[key] = startSpeed += 0.11;
                        }
                    });

                    var portfolioOffsetTop = $('.c-grid__item').parent().offset().top,
                        portfolioOffsetHalf = $('.c-grid__item').parent().height() / 2,
                        portfolioOffset = portfolioOffsetTop - portfolioOffsetHalf;

                    if (!Util.isHome) {
                        portfolioOffset = 0;
                    }

                    $window.on('scroll', function () {
                        $('.c-grid__item').each(function () {
                            var el = $(this),
                                step,
                                elPos = $(this).data('pos');

                            step = elObj[elPos];

                            var windowTop = $window.scrollTop();
                            if (windowTop >= 0) {
                                var newCoord = (portfolioOffset - windowTop) * step;
                                $(el).css('transform', 'translateY( ' + newCoord + 'px)');
                            }
                        });
                    });
                }
            } else {
                $window.on('scroll', function () {
                    $('.c-grid__item').css('transform', 'translateY( 0 )');
                });
            }
        };

        this.chocolat = function () {
            var $container = $('.chocolat-parent');

            if ($container.length) {
                $container.imagesLoaded(function () {

                    $container.find('a').each(function (i, v) {
                        if ($(this).find('> img').length) {
                            $(this).find('> img').addClass('chocolat-item');
                            $(this).addClass('chocolat-image');
                        }
                    });

                    $container.Chocolat({
                        loop: true,
                        duration: 500,
                        afterMarkup: function () {
                            var _this = this,
                                imgArr = this.settings.images;
                            this.elems.top.prepend('<span class="chocolat-grid"><i class="material-icons">apps</i></span>');
                            this.elems.content.prepend('<ul class="chocolat-grid-list"></ul>');
                            for (var i = 0; i < imgArr.length; i++) {
                                $('.chocolat-grid-list').append('<li><img class="chocolat-item-img" src="' + imgArr[i].src + '"/></li>');
                            }

                            $('.chocolat-item-img').each(function (i, v) {
                                $(this).on('click', function () {
                                    _this.api().open(i);
                                    $('.chocolat-content .chocolat-img, .chocolat-bottom, .chocolat-left, .chocolat-right').show();
                                    $('.chocolat-grid-list').hide();
                                    $body.removeClass('chocolat-thumbs-open');

                                });
                            });

                            $('.chocolat-grid').on('click', function () {
                                $('.chocolat-content .chocolat-img, .chocolat-bottom, .chocolat-left, .chocolat-right').hide();
                                $('.chocolat-grid-list').show();
                                $body.addClass('chocolat-thumbs-open');

                            });

                            $('.chocolat-close').html('<i class="material-icons">add_circle_outline</i>');
                            $('.chocolat-left').html('<i class="material-icons">arrow_back</i>');
                            $('.chocolat-right').html('<i class="material-icons">arrow_forward</i>');

                            if (Util.isLogged) {
                                $('.chocolat-top').css('top', '32px');
                            }
                        },

                        afterImageLoad: function () {
                            $('.chocolat-content').hide().fadeIn(1000);
                        }
                    });
                    $('.chocolat-item').click(function () {
                        setTimeout(function () {
                            var checkChocolat = setInterval(function () {
                                if ($body.hasClass('chocolat-open')) {
                                    $('#masthead').css('position', 'relative');
                                } else {
                                    $('#masthead').css('position', 'fixed');
                                    clearInterval(checkChocolat);
                                }
                            }, 100);
                        }, 500);
                    });
                });
            }
        };

    };

    Portfolio.prototype.init = function () {
        var _this = this;

        // if (isiPhone && isSafari && $body.hasClass('single-portfolio')) {
        //     $('.white-space').css('margin-bottom', '80px');
        // }

        if (this.$container.length) {
            _this.$container.imagesLoaded(function () {

                _this.titlePositioning();

                _this.filter();

                _this.parallax();

            });
        }

        this.chocolat();

    };

    //Header
    var Header = function () {
        var $navbar = $body.find('.c-navbar');

        this.stickyHeader = function () {
            var header = $('.c-header'),
                headerHeight = header.outerHeight(),
                homeHeaderPos = header.offset().top,
                sticky = !!header.hasClass('c-header--sticky');

            $('.single-portfolio .post-thumbnail').css('height', $window.height());

            if (Util.isHome) {
                if (sticky) {
                    $window.scroll(function () {
                        if ($window.scrollTop() >= homeHeaderPos) {

                            header.css('position', 'fixed');
                            Util.isLogged ? header.css('top', '32px') : header.css('top', '0');

                            $('.site-content').css('padding-top', headerHeight);
                        } else {
                            header.css('position', 'relative');
                            header.css('top', '0');
                            $('.site-content').css('padding-top', 0);
                        }
                    });
                }
            } else {
                if (sticky) {
                    header.css('position', 'fixed');
                    Util.isLogged ? header.css('top', '32px') : header.css('top', '0');
                    $('.site-content').css('padding-top', headerHeight);
                }
                if ($body.hasClass('single-portfolio')) {
                    $('.c-grid--header').css('padding-top', $window.height() - headerHeight + 30);
                    $('.site-content').css('padding-top', 0);
                    header.addClass('inverted');
                    $window.scroll(function () {
                        if ($window.scrollTop() > $window.height()) {
                            header.removeClass('inverted');
                        } else {
                            header.addClass('inverted');
                        }
                    });
                }
            }
        };
        this.headerEvents = function () {
            if ($navbar.length) {
                //search button
                $('.c-navbar__search-icon').on('click', function () {
                    if (Util.isLogged) {
                        $('.c-navbar__search').css('top', '32px');
                    }
                    setTimeout(function () {
                        $('.c-navbar__search-holder .search-field').focus();
                    }, 1000);

                    $(this).toggleClass('open');
                    $('.c-navbar__search').toggleClass('is-active');
                    $('#toggle-hamburger').toggleClass('hidden-item');
                });

                //menu button
                $('#toggle-hamburger').on('click', function () {
                    $(this).toggleClass('active');
                    $('#hamburger').toggleClass('open');
                    $body.toggleClass('overlay-open');
                    $('.c-navbar__zone--left').css('z-index', '0');
                    $('.c-navbar__search-icon').toggleClass('hidden-item');
                });

                $body.keydown(function (e) {
                    if (e.keyCode === 27) { // esc
                        if ($('.c-navbar__search').hasClass('is-active')) {
                            $('.c-navbar__search').removeClass('is-active');
                            $('.c-navbar__search-icon').removeClass('open');
                            $('#toggle-hamburger').toggleClass('hidden-item');
                        }

                        if ($('#hamburger').hasClass('open')) {
                            $('#toggle-hamburger').removeClass('active');
                            $('#hamburger').removeClass('open');
                            $body.removeClass('overlay-open');
                            $('.c-navbar__search-icon').toggleClass('hidden-item');
                        }
                    }
                    $('.c-navbar__search-icon').on('click', function () {
                        $(this).toggleClass('open');
                    });
                });
            }
        };
    }

    Header.prototype.init = function () {
        this.stickyHeader();
        this.headerEvents();
    };

    //Blog

    var Blog = function () {
        var _this = this;

        this.$container = $('.o-layout--blog');

        this.novalidateCommentForm = function () {
            var commentForm = $('#commentform');
            if (commentForm.length) {
                commentForm.removeAttr('novalidate');
            }
        };

        this.showArticleComments = function () {
            $('.c-comments-toggle__label').on('click', function () {
                $('.c-comments').slideToggle();
            });
        };

        this.blogOrientation = function () {
            if ($('.o-layout--blog').length) {
                $('.o-layout--blog > article').each(function (i, obj) {
                    if ($(this).find('.c-card .c-card__frame > img').hasClass('size-theia-blog-grid-card-portrait')) {
                        $(this).find('.c-card').addClass('portrait');
                    } else if ($(this).find('.c-card__frame > img').hasClass('size-theia-blog-grid-card-landscape')) {
                        $(this).find('.c-card').addClass('landscape')
                    }
                });
            }
        };

        this.getNavigation = function () {
            if (this.$container.data('navigation') !== undefined) {
                return this.$container.data('navigation');
            } else {
                return false;
            }
        };

        this.infiniteScroll = function () {

            $('.post-listing').append('<div class="actions">' +
                '<span class="loading-gif"></span>' +
                '<span class="loading-status"></span>' +
                '</div>');

            var actions = $('.post-listing .actions'),
                loading = $('.actions .loading-blog'),
                status = $('.actions .loading-status'),
                page = 2,
                scrollHandling = {
                    allow: true,
                    reallow: function () {
                        scrollHandling.allow = true;
                    },
                    delay: 300 //(milliseconds) adjust to the highest acceptable value
                };

            $window.scroll(function () {
                if (scrollHandling.allow) {
                    scrollHandling.allow = false;
                    setTimeout(scrollHandling.reallow, scrollHandling.delay);
                    var offset = $(actions).offset().top - $window.scrollTop();
                    if (2000 > offset) {
                        $.ajax({
                            url: infiniteScrollObj.url,
                            type: "POST",
                            data: {
                                action: 'theia_blog_infinite_scroll',
                                page: page,
                                query: infiniteScrollObj.query
                            },
                            beforeSend: function () {
                                loading.show();
                            }
                        }).done(function (res) {
                            loading.hide();
                            if (res.success) {
                                if (res.data !== '') {
                                    $('.post-listing').append(res.data);
                                    $('.post-listing').append(actions);
                                    _this.blogOrientation();
                                    page = page + 1;
                                } else {
                                    status.text('There are no more posts to load.');
                                }
                            } else {
                                console.log(res);
                            }
                        }).fail(function (xhr, textStatus, e) {
                            console.log(xhr.responseText);
                        });

                    }
                }
            });
        };

        this.loadMore = function () {

            $('.post-listing').append('<div class="actions">' +
                '<a class="c-btn c-btn_load__more">Load more</a>' +
                '<span class="loading-gif"></span>' +
                '<span class="loading-status"></span>' +
                '</div>');

            var actions = $('.post-listing .actions'),
                button = $('.actions .c-btn_load__more'),
                loading = $('.actions .loading-blog'),
                status = $('.actions .loading-status'),
                page = 2;

            $body.on('click', '.c-btn_load__more', function () {
                $.ajax({
                    url: loadMoreObj.url,
                    type: "POST",
                    data: {
                        action: 'theia_blog_load_more',
                        page: page,
                        query: loadMoreObj.query
                    },
                    beforeSend: function () {
                        loading.show();
                        button.hide();
                    }
                }).done(function (res) {
                    loading.hide();
                    if (res.success) {
                        if (res.data !== '') {
                            $('.post-listing').append(res.data);
                            $('.post-listing').append(actions);
                            button.show();
                            _this.blogOrientation();
                            page = page + 1;
                        } else {
                            button.hide();
                            status.text('There are no more posts to load.');
                        }

                    } else {
                        console.log(res);
                    }
                }).fail(function (xhr, textStatus, e) {
                    console.log(xhr.responseText);
                });
            });
        }
    };

    Blog.prototype.init = function () {

        this.novalidateCommentForm();

        this.showArticleComments();

        this.blogOrientation();

        if (this.getNavigation() === 'infinite_scroll') {
            if (this.$container.height() <= ($window.height() - this.$container.offset().top)) {
                this.loadMore();
            } else {
                this.infiniteScroll();
            }
        } else if (this.getNavigation() === 'load_more') {
            this.loadMore();
        }

    };

    //AcidStudios
    var AcidStudiosTheme = function () {
        this.debug = false;

        this.LoadingTime = function () {
            var load = window.performance.timing.domContentLoadedEventEnd - window.performance.timing.navigationStart,
                loadTime = 'Loading time: ' + (load / 1000).toFixed(1) + 's';
            return loadTime;
        };

        this.log = function (message, loadingTime) {
            if (this.debug === true) {
                var style = 'background: #000; color: #C9E967';

                if (loadingTime !== undefined) {
                    console.log('%c ' + message + '(' + this.LoadingTime() + ')', style);
                } else {
                    console.log('%c ' + message, style);
                }
            }
        };

    };

    var Theia = new AcidStudiosTheme();

    Theia.utils = function () {
        Util.platformDetect();
        if (isSafari) {
            $('.single-portfolio .post-thumbnail').css('will-change', 'transform');
        }

        Util.loaderEffect();

        Util.triggerSocialButton();

        Util.removeEmptyPTags();

        Util.hideWoocommerceIcon();
    };

    Theia.init = function () {

        Theia.HeroArea = new HeroArea();
        Theia.Header = new Header();
        Theia.Portfolio = new Portfolio();
        Theia.Blog = new Blog();
    };

    Theia.events = function () {
        Theia.HeroArea.load();
        Theia.HeroArea.init();

        Theia.Header.init();

        Theia.Portfolio.init();

        Theia.Blog.init();
    };

    Theia.init();

    $document.ready(function () {
        Theia.utils();
        Theia.events();

        $window.on('resize',
            Util._debounce(function () {
                Theia.Portfolio.parallax();
                Theia.Portfolio.destroyTitlePositioning();
                Theia.Portfolio.titlePositioning();
            }, 400));
    });

    $window.on('load', function () {
        var preloaderFadeOutTime = 500;

        function hidePreloader() {
            var preloader = jQuery('.c-loader');
            preloader.fadeOut(preloaderFadeOutTime);
        }

        setTimeout(function () {
            hidePreloader();
        }, 400);
    });

})(jQuery, window, document);



