<?php
/**
 * The template for displaying comments
 *
 * This is the template that displays the area of the page that contains both the current comments
 * and the comment form.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package THEIA
 */

/*
 * If the current post is protected by a password and
 * the visitor has not yet entered the password we will
 * return early without loading the comments.
 */
if (post_password_required()) {
    return;
}
?>
<label class="c-comments-toggle__label">
    <span class="c-comments-toggle__icon"><i class="material-icons">comment</i></span>
    <span class="c-comments-toggle__number"><?php comments_number( 'Leave a comment', 'one comment', '% comments' ); ?></span>
</label>
<div id="comments" class="c-comments comments-area u-content-width">

    <?php
    if (have_comments()) :

        the_comments_navigation(); ?>

        <ol class="c-comments__list comment-list">
            <?php
            wp_list_comments( array(
                'callback' => 'better_comments'
            ) );
            ?>
        </ol>

        <?php
        the_comments_navigation();

        if (!comments_open()) :
            ?>
            <p class="c-comments__none no-comments"><?php esc_html_e('Comments are closed.', 'theia'); ?></p>
        <?php
        endif;

    endif;

    $args = array(
        'comment_field' => '<p class="comment-form-comment"><textarea id="comment" required="required" name="comment" cols="45" rows="8" aria-required="true" placeholder="Enter your toughts here"></textarea></p>',
        'fields' => apply_filters('comment_form_default_fields', array(
                'author' =>
                    '<p class="comment-form-author">' .
                    '<input id="author" name="author" type="text" value="' . esc_attr($commenter['comment_author']) .
                    '" placeholder="Introduce yourself" size="30" required="required" /></p>',

                'email' =>
                    '<p class="comment-form-email">' .
                    '<input id="email" name="email" type="text" value="' . esc_attr($commenter['comment_author_email']) .
                    '" placeholder="Your email is required" size="30" required="required" /></p>',

                'url' =>
                    '<p class="comment-form-url">' .
                    '<input id="url" name="url" type="text" value="' . esc_attr($commenter['comment_author_url']) .
                    '" placeholder="Your website" size="30" /></p>',


            )

        ),
        'title_reply' => __('Unleash your toughts about this post', 'theia'),
        'title_reply_to' => __('Unleash your toughts about this post to %s', 'theia'),
        'label_submit' => __('Post your comment', 'theia'),
    );

    comment_form($args);
    ?>

</div><!-- #comments -->
